package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import take_away_assistant.util;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanGoods;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;

public class FrmRecommend  extends JDialog implements ActionListener{
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnCancel = new Button("����");
	private Object tblAddrTitle[]={"��Ʒ���","�̼ұ��","����"};
	private Object tblAddrData[][];
	DefaultTableModel tabAddrModel=new DefaultTableModel();
	private JTable dataTableAddr=new JTable(tabAddrModel);
	public List<String> recommendGoods=null;
	public void reloadRecommendTabel() {
		try {
			if(util.goodsManager.loadRecomend()==null)
				return;
			else 
				recommendGoods=util.goodsManager.loadRecomend();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		//��������
				tblAddrData =  new Object[3][3];
				for(int i=0;i<3;i++){//��������  ����ÿһplan
					for(int j=0;j<3;j++)
					 tblAddrData[i][j]=recommendGoods.get(i*3+j);
				}
				//����ģ��
				tabAddrModel.setDataVector(tblAddrData,tblAddrTitle);//�������ݺͱ�ͷ
				this.dataTableAddr.validate();
				this.dataTableAddr.repaint();
				
	}
	
	public FrmRecommend(Frame f, String s, boolean b) {
		super(f, s, b);
		
		
		reloadRecommendTabel();
		this.getContentPane().add(new JScrollPane(this.dataTableAddr), BorderLayout.CENTER);
		
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(300, 200);
		this.btnCancel.addActionListener(this);
		
		
		//��ʾ����Ļ�м�
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				this.validate();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		
	}
}
