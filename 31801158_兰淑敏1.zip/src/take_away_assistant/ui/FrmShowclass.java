

package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import take_away_assistant.util;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanClass;
import take_away_assistant.bean.BeanGoods;
import take_away_assistant.others.BaseException;

public class FrmShowclass extends JDialog implements ActionListener{
	public static BeanAddr a=new BeanAddr();//�����޸ĵ�ַ
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnCancel = new Button("����");
	private Button btnAdd = new Button("����");
	private Button btnDelete = new Button("ɾ��");
	
	private Object tblAddrTitle[]=BeanAddr.tableTitles;
	private Object tblAddrData[][];
	DefaultTableModel tabAddrModel=new DefaultTableModel();
	private JTable dataTableAddr=new JTable(tabAddrModel);
	
	public List<BeanClass> allAddr=null;
	public void reloadAllClass() {
		try {
			allAddr=util.classManager.loadAllClass();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		//��������
				tblAddrData =  new Object[allAddr.size()][BeanAddr.tableTitles.length];
				for(int i=0;i<allAddr.size();i++){//��������  ����ÿһplan
					for(int j=0;j<BeanClass.tableTitles.length;j++)
					 tblAddrData[i][j]=allAddr.get(i).getCell1(j);
				}
				//����ģ��
				tabAddrModel.setDataVector(tblAddrData,tblAddrTitle);//�������ݺͱ�ͷ
				this.dataTableAddr.validate();
				this.dataTableAddr.repaint();
				
	}
	public FrmShowclass(Frame f, String s, boolean b) {
		super(f, s, b);
		reloadAllClass();
		this.getContentPane().add(new JScrollPane(this.dataTableAddr), BorderLayout.CENTER);
		
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));
		toolBar.add(btnAdd);
		toolBar.add(btnDelete);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(620, 320);
		
		this.btnAdd.addActionListener(this);
		this.btnDelete.addActionListener(this);
		this.btnCancel.addActionListener(this);
		
		
		//��ʾ����Ļ�м�
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		this.validate();
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnDelete){
			int i=FrmShowclass.this.dataTableAddr.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ�����", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			try {
				util.classManager.delete(this.allAddr.get(i));
				JOptionPane.showMessageDialog(null, "ɾ���ɹ�");  
				reloadAllClass();
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		else if(e.getSource()==this.btnAdd){
			FrmMaddClass dlg=new FrmMaddClass(this,"����",true);
			dlg.setVisible(true);
			reloadAllClass();
		}
		
		
	}
}
