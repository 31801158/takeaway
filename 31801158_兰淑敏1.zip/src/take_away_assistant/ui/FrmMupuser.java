package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import take_away_assistant.util;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;

public class FrmMupuser extends JDialog implements ActionListener{

	//private static final String FrmSMsg = null;
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	private JLabel labelID = new JLabel            ("�û���ţ�        ");//�����Ը�
	private JLabel labelID1 = new JLabel("");
	private JLabel labelName = new JLabel          ("�û�����           ");
	private JTextField edtName = new JTextField(20);
	private JLabel labelSex = new JLabel           ("�Ա�               ");
	private JTextField edtSex = new JTextField(20);
	private JLabel labelPwd = new JLabel           ("���룺               ");
	private JTextField edtPwd = new JTextField(20);
	private JLabel labelTel = new JLabel           ("�ֻ����룺        ");
	private JTextField edtTel = new JTextField(20);
	private JLabel labelMail = new JLabel          ("���䣺               ");
	private JTextField edtMail = new JTextField(20);
	private JLabel labelCity = new JLabel          ("���ڳ��У�        ");
	private JTextField edtCity = new JTextField(20);
	private JLabel labelRegistertime = new JLabel  ("ע��ʱ�䣺        ");//�����Ը�
	private JLabel labelRegistertime1 = new JLabel ("");
	private JLabel labelVip = new JLabel           ("�Ƿ�Ϊ��Ա��    ");
	private JTextField edtVip = new JTextField(20);
	private JLabel labelDeadline = new JLabel      ("��Ա��ֹʱ�䣺");
	private JTextField edtDeadline = new JTextField(20);
	
	public FrmMupuser(Frame f, String s, boolean b) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		
		workPane.setLayout(new GridLayout(10,2));
		labelID1.setText(Integer.toString(FrmManager.curcustomer.getUser_id())+"    ");
		workPane.add(labelID);
		workPane.add(labelID1);
		
		edtName.setText(FrmManager.curcustomer.getcustomer_name());
		workPane.add(labelName);
		workPane.add(edtName);
		
		edtSex.setText(FrmManager.curcustomer.getcustomer_sex());
		workPane.add(labelSex);
		workPane.add(edtSex);
		
		edtPwd.setText(FrmManager.curcustomer.getPwd());
		workPane.add(labelPwd);
		workPane.add(edtPwd);
		
		edtTel.setText(FrmManager.curcustomer.getcustomer_tel());
		workPane.add(labelTel);
		workPane.add(edtTel);
		
		edtMail.setText(FrmManager.curcustomer.getcustomer_mail());
		workPane.add(labelMail);
		workPane.add(edtMail);
		
		edtCity.setText(FrmManager.curcustomer.getcustomer_city());
		workPane.add(labelCity);
		workPane.add(edtCity);
		String redatetime=null;
//		if(BeanUser.currentLoginUser.getRegister_time()==null||"".equals(BeanUser.currentLoginUser.getRegister_time()))redatetime=null;
//		else
		redatetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(FrmManager.curcustomer.getRegister_time());  // ��ȡ������ʱ����
		
		labelRegistertime1.setText(redatetime);
		workPane.add(labelRegistertime);
		workPane.add(labelRegistertime1);
		
//		if(FrmManager.curcustomer.getVip().equals("��")){
//		String deadlinedatetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(FrmManager.curcustomer.getvip_deadline());
//		edtDeadline.setText(deadlinedatetime.substring(0,10));//������10
//		}
//		else edtDeadline.setText(" ");
		edtVip.setText(FrmManager.curcustomer.getVip());
		workPane.add(labelVip);
		workPane.add(edtVip);
		workPane.add(labelDeadline);
		workPane.add(edtDeadline);
		
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(360, 280);
		
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);
		
		//��ʾ����Ļ�м�
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		this.validate();
}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){
			String id=labelID.getText();
			String name=edtName.getText();
			String sex=edtSex.getText();
			String pwd=edtPwd.getText();
			String tel=edtTel.getText();
			String mail=edtMail.getText();
			String city=edtCity.getText();
			String registertime=labelRegistertime1.getText();
			String vip=edtVip.getText();
			String deadline=edtDeadline.getText();
			try {
				util.userManager.update(FrmManager.curcustomer,id,name,sex,pwd,tel,mail,city,registertime,vip,deadline);
				this.setVisible(false);
				return;
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			
		}
		
	}

}
