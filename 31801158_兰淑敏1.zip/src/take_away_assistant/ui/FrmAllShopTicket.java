package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import take_away_assistant.util;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.others.BaseException;

public class FrmAllShopTicket extends JDialog implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel workPane = new JPanel();
	private JMenuBar menubar=new JMenuBar(); 
	private Button btnCancel = new Button("����");
	private JPanel toolBar = new JPanel();


	
	private Object tblRightData[][];
	DefaultTableModel tabRightModel=new DefaultTableModel();
	private JTable dataTableRight=new JTable(tabRightModel);
	public Object tblRightTitle[]=BeanTicket.tableTitles1;
	List<BeanTicket> allticket=null;
	protected void reloadRightTabel() {
		int i;
		for(i=0;i<BeanTicket.tableTitles1.length;i++){
			tblRightTitle[i]=BeanTicket.tableTitles1[i];
		}
		try {
			allticket=util.ticketManager.loadTicket1();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblRightData =  new Object[allticket.size()][BeanTicket.tableTitles1.length];
		for(i=0;i<allticket.size();i++){
			for(int j=0;j<BeanTicket.tableTitles1.length;j++){
				tblRightData[i][j]=allticket.get(i).getCell11(j);
				}
		}
		tabRightModel.setDataVector(tblRightData,tblRightTitle);
		this.dataTableRight.validate();
		this.dataTableRight.repaint();
	}
	
	public FrmAllShopTicket(Frame f, String s, boolean b) {
		super(f, s, b);
		reloadRightTabel();
		this.getContentPane().add(new JScrollPane(this.dataTableRight), BorderLayout.CENTER);
		
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));

		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(620, 320);
		

		this.btnCancel.addActionListener(this);
		
		
		//��ʾ����Ļ�м�
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		this.validate();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
	}
}
