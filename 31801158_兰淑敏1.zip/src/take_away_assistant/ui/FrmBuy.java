package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import take_away_assistant.util;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;

public class FrmBuy  extends JDialog implements ActionListener{
		
		private JPanel toolBar = new JPanel();
		private JPanel workPane = new JPanel();
		private Button btnOk = new Button("ȷ���µ�");
		private Button btnCancel = new Button("����");
		
		private JLabel labelID = new JLabel          ("�Ż�ȯ��ţ�    ");
		private JLabel labelrequire_arrive = new JLabel("Ҫ���ʹ�ʱ�䣺   ");
		private JLabel labeladdress = new JLabel("��ַ��ţ�   ");

		
		
		private JTextField edtTicket=new JTextField(20);
		private JTextField edtrequire_arrive=new JTextField(20);
		private JTextField edtaddress=new JTextField(20);
//		private JLabel labelName1 = new JLabel        ("");
//		private JLabel labelSex1 = new JLabel         ("");
//		
//		private JLabel labelTel1 = new JLabel         (BeanUser.currentLoginUser.getcustomer_tel()); //(BeanUser.currentLoginUser.getcustomer_tel());
//		private JLabel labelMail1 = new JLabel        ("");
//		private JLabel labelCity1 = new JLabel        ("");
//		String redatetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(BeanUser.currentLoginUser.getRegister_time());  // ��ȡ������ʱ����
//		private JLabel labelRegisterTime1 = new JLabel(redatetime);
//		private JLabel labelVip1 = new JLabel("�ǻ�Ա");
//		private JLabel labelVipdeadline1 = new JLabel("");
				
		public FrmBuy(Frame f, String s, boolean b) {
			super(f, s, b);
			toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));
			toolBar.add(btnOk);
			toolBar.add(btnCancel);
			this.getContentPane().add(toolBar, BorderLayout.SOUTH);

			
			workPane.add(labelID);
			workPane.add(edtTicket);
			workPane.add(labelrequire_arrive);
			workPane.add(edtrequire_arrive);
			workPane.add(labeladdress);
			workPane.add(edtaddress);
			this.getContentPane().add(workPane, BorderLayout.CENTER);
			this.setSize(300, 240);
			this.btnCancel.addActionListener(this);
			this.btnOk.addActionListener(this);
			//��ʾ����Ļ�м�
			double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
			double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
			this.setLocation((int) (width - this.getWidth()) / 2,
					(int) (height - this.getHeight()) / 2);
			this.validate();
		}
		
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==this.btnCancel)
				this.setVisible(false);
			else if(e.getSource()==this.btnOk){
				if(FrmSTicket.allTicket==null){
					JOptionPane.showMessageDialog(null, "���Ȳ鿴����Ż�ȯ��");
					return;
				}
				try {
					
					if(util.ordersManager.insert(FrmMain.curShop.getShop_id(),BeanUser.currentLoginUser.getUser_id(),this.edtTicket.getText(),this.edtrequire_arrive.getText(),this.edtaddress.getText())==1)
					JOptionPane.showMessageDialog(null, "<���µ�>");
					this.setVisible(false);
				} catch (BaseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
				
			
		}

	}
