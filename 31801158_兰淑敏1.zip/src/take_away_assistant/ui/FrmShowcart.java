package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


import take_away_assistant.util;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanCart;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;

public class FrmShowcart extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnCancel = new Button("����");
	private Button btnremove = new Button("�Ƴ����ﳵ");
	
	private Object tblCartTitle[]=BeanCart.tableTitles;
	private Object tblCartData[][];
	DefaultTableModel tabCartModel=new DefaultTableModel();
	private JTable dataTableCart=new JTable(tabCartModel);
	
	
	public static List<BeanCart> allcart=null;
	public void reloadCartTabel() {
		try {
			allcart=util.cartManager.loadCart();//�г�����
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		//��������
				tblCartData =  new Object[allcart.size()][BeanCart.tableTitles.length];
				for(int i=0;i<allcart.size();i++){//��������  ����ÿһplan
					for(int j=0;j<BeanCart.tableTitles.length;j++)
						try {
							
							tblCartData[i][j]=allcart.get(i).getCell(j);
							
						} catch (DbException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (BusinessException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					//����ÿһ����Ԫ��
				}
				//����ģ��
				tabCartModel.setDataVector(tblCartData,tblCartTitle);//�������ݺͱ�ͷ
				this.dataTableCart.validate();
				this.dataTableCart.repaint();
				
				
	}
	public FrmShowcart(Frame f, String s, boolean b) {
		super(f, s, b);
		reloadCartTabel();
		this.getContentPane().add(new JScrollPane(this.dataTableCart), BorderLayout.CENTER);
		
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));
	
		toolBar.add(btnCancel);//����
		toolBar.add(btnremove);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(620, 320);
		
		
		this.btnCancel.addActionListener(this);
		this.btnremove.addActionListener(this);
		
		//��ʾ����Ļ�м�
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		this.validate();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnremove){
			int i=FrmShowcart.this.dataTableCart.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ����Ʒ", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			try {
				util.cartManager.remove(this.allcart.get(i));
				this.reloadCartTabel();
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
	}

}
