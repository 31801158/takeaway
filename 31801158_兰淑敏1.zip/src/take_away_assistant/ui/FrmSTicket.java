package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import take_away_assistant.util;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;

public class FrmSTicket  extends JDialog implements ActionListener{
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnCancel = new Button("����");

	
	private Object tblTicketTitle[]=BeanTicket.tableTitles;
	private Object tblTicketData[][];
	DefaultTableModel tabTicketModel=new DefaultTableModel();
	private JTable dataTableTicket=new JTable(tabTicketModel);
	
	public static List<BeanTicket> allTicket=null;
	public static List<BeanTicket> allTicket1=null;
	public void reloadTicketTabel() {
		try {
			allTicket=util.ticketManager.loadTicket();
			allTicket1=util.ticketManager.loadTicketProcess();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		//��������
				tblTicketData =  new Object[allTicket.size()+allTicket1.size()+1][BeanTicket.tableTitles.length];
				for(int i=0;i<allTicket.size();i++){//��������  ����ÿһticket
					for(int j=0;j<BeanTicket.tableTitles.length;j++){
						tblTicketData[i][j]=allTicket.get(i).getCell(j);
					}
				}
				tblTicketData[allTicket.size()][0]="�̼ұ��";
				tblTicketData[allTicket.size()][1]="�Ż�ȯ���";
				tblTicketData[allTicket.size()][2]="����Ҫ����";
				tblTicketData[allTicket.size()][3]="�����";
				tblTicketData[allTicket.size()][4]="";

				for(int i=allTicket.size()+1;i<allTicket.size()+allTicket1.size()+1;i++){
					for(int j=0;j<BeanTicket.tableTitles.length;j++){
						tblTicketData[i][j]=allTicket1.get(i-allTicket.size()-1).getCell1(j);
					}
				}
				//����ģ��
				tabTicketModel.setDataVector(tblTicketData,tblTicketTitle);//�������ݺͱ�ͷ
				this.dataTableTicket.validate();
				this.dataTableTicket.repaint();
				
	}
	public FrmSTicket(Frame f, String s, boolean b) {
		super(f, s, b);
		reloadTicketTabel();
		this.getContentPane().add(new JScrollPane(this.dataTableTicket), BorderLayout.CENTER);
		
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));

		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(620, 320);
		

		this.btnCancel.addActionListener(this);
		
		
		//��ʾ����Ļ�м�
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		this.validate();
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		
	}
}
