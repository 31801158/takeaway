package take_away_assistant.bean;

import java.math.BigDecimal;

import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;

public class BeanAddr {
	public static final String[] tableTitles={"��ַ���","��ַ"};
	private int address_id;
	private int customer_id;
	private String provience;
	private String town;
	private String block;
	private String specific_address;
	private String contact_name;
	private String contact_tel;
	public String getCell(int col) throws DbException, BusinessException{
			if(col==0) return Integer.toString(this.address_id);
			if(col==1) return provience+town+block+specific_address+" "+contact_name+" "+contact_tel;//��ַ�ϳ�һ���ַ���������ʾ
//			else if(col==2) return  provience;
//			else if(col==3) return town;
//			else if(col==4) return block;
//			else if(col==5) return specific_address;
//			else if(col==6) return contact_name;
//			else if(col==7) return contact_tel;
			else return "";
		
		
	}
	
	public void setAddress_id(int shopid){
		this.address_id=shopid;
	}
	public int getAddress_id(){
		return address_id;
	}
	
	public void setCustomer_id(int shopid){
		this.customer_id=shopid;
	}
	public int getCustomer_id(){
		return customer_id;
	}
	
	public void setProvience(String shopname){
		this.provience=shopname;
	}
	public String getProvience(){
		return provience;
	}
	public void setTown(String shopname){
		this.town=shopname;
	}
	public String getTown(){
		return town;
	}
	public void setBlock(String shopname){
		this.block=shopname;
	}
	public String getBlock(){
		return block;
	}
	public void setSpecific_address(String shopname){
		this.specific_address=shopname;
	}
	public String getSpecific_address(){
		return specific_address;
	}
	
	public void setContact_name(String shopname){
		this.contact_name=shopname;
	}
	public String getContact_name(){
		return contact_name;
	}
	public void setContact_tel(String shopname){
		this.contact_tel=shopname;
	}
	public String getContact_tel(){
		return contact_tel;
	}
}
