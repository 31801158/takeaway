package take_away_assistant.bean;

import java.text.SimpleDateFormat;

public class BeanOrderDetil {
	public static final String[] tblStepTitle={"�������","��Ʒ���","����","�۸�","��Ʒ�Żݽ��"};
	
	
	private int order_id;
	private int goods_id;
	private int count;
	private float price;
	private float d_price;
	public String getCell(int col){
		if(col==0) return Integer.toString(this.order_id);
		else if(col==1) return Integer.toString(this.goods_id);
		else if(col==2) return Integer.toString(this.count);
		else if(col==3) return Float.toString(this.price);
		else if(col==4) return Float.toString(this.d_price);

		else return "";
	}
	
	public void setorder_id(int stepid){
		this.order_id=stepid;
	}
	public int getorder_id(){
		return order_id;
	}
	
	public void setgoods_id(int planid){
		this.goods_id=planid;
	}
	public int getgoods_id(){
		return goods_id;
	}
	
	public void setcount(int planid){
		this.count=planid;
	}
	public int getcount(){
		return count;
	}
	
	public void setprice(float planid){
		this.price=planid;
	}
	public float getprice(){
		return price;
	}
	
	public void setd_price(float planid){
		this.d_price=planid;
	}
	public float getd_price(){
		return d_price;
	}
}
