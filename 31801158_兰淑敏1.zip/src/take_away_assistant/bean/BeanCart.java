package take_away_assistant.bean;

import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;

public class BeanCart {
	public static final String[] tableTitles={"�̵�","��Ʒ����","����","ԭ��","���ڹ�����Żݼ�"};
	private int shop_id;
	private int customer_id;
	private int goods_id;
	private int class_id;
	private String shop_name;
	private String goods_name;
	private int count;
	private float price;
	private float d_price;
	public String getCell(int col) throws DbException, BusinessException{
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select good_name,price,d_price from goods_msg where goods_id="+this.goods_id;
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				this.goods_name=rs.getString(1);
				this.price=rs.getFloat(2);
				this.d_price=rs.getFloat(3);
			}

			sql="select shop_name from shop_msg where shop_id="+this.shop_id;
			rs=st.executeQuery(sql);
			if(rs.next()){
				this.shop_name=rs.getString(1);
			}
			
			sql="select goods_count from cart "
					+ " where shop_id="+shop_id+" and class_id="+class_id+" and goods_id="+goods_id+" and customer_id="+customer_id;
			rs=st.executeQuery(sql);
			if(rs.next()){
				this.count=rs.getInt(1);
			}
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
			if(col==0) return this.shop_name;
			if(col==1) return this.goods_name;
			else if(col==2) return  Integer.toString(this.count);
			else if(col==3) return  Float.toString(this.price);
			else if(col==4) return  Float.toString(this.d_price);
			else return "";
		
		
	}



	public void setshop_id(int shopname){
		this.shop_id=shopname;
	}
	public int getshop_id(){
		return shop_id;
	}
	public void setcustomer_id(int shopname){
		this.customer_id=shopname;
	}
	public int getcustomer_id(){
		return customer_id;
	}
	public void setgoods_id(int shopname){
		this.goods_id=shopname;
	}
	public int getgoods_id(){
		return goods_id;
	}
	public void setclass_id(int shopname){
		this.class_id=shopname;
	}
	public int getclass_id(){
		return class_id;
	}
	public void setShop_name(String shopname){
		this.shop_name=shopname;
	}
	public String getShop_name(){
		return shop_name;
	}
	
	
	public void setgoods_name(String shopname){
		this.goods_name=shopname;
	}
	public String getgoods_name(){
		return goods_name;
	}
	
	public void setcount(int shopname){
		this.count=shopname;
	}
	public int getcount(){
		return count;
	}
	
	
	public void setprice(float shopname){
		this.price=shopname;
	}
	public float getprice(){
		return price;
	}
	public void setd_price(float shopname){
		this.d_price=shopname;
	}
	public float getd_price(){
		return d_price;
	}
}
