package take_away_assistant.bean;

public class BeanManager {
	public static BeanManager currentLoginManager=null;//ȫ�ֱ�����ǰ����Ա
	private int m_id;
	private String m_name;
	private String m_pwd;
	
	public void setm_id(int userid) {
		this.m_id=userid;
	}
	public int getm_id(){
		return m_id;
	}
	
	public void setPwd(String newPwd) {
		this.m_pwd=newPwd;
	}
	public String getPwd(){
		return m_pwd;
	}
	
	public void setm_name(String newPwd) {
		this.m_name=newPwd;
	}
	public String getm_name(){
		return m_name;
	}
}
