package take_away_assistant.bean;


public class BeanGoods {
	public static final String[] tblGoodsTitle={"��Ʒ���","��Ʒ����","ԭ��","���ڹ�����Żݼ�","��Ʒʣ�����","����"};
	public static final String[] tableTitles={"��Ʒ���","���������","��Ʒ����","ԭ��","���ڹ�����Żݼ�"};
	private int  goods_id;
	private String goods_name;
	private int goods_class_id;
	private float price;
	private float d_price;
	private int stock;
	private int sales;
	public String getCell(int col){
		if(col==0) return Integer.toString(this.goods_id);
		else if(col==1) return this.goods_name;
		else if(col==2) return Float.toString(this.price);
		else if(col==3) return Float.toString(this.d_price);
		else if(col==4) return Integer.toString(this.stock);
		else if(col==5) return Integer.toString(this.sales);
		else return "";
	}
	public String getCell1(int col){
		if(col==0) return Integer.toString(this.goods_id);
		else if(col==1) return Integer.toString(this.goods_class_id);
		else if(col==2) return this.goods_name;
		else if(col==3) return Float.toString(this.price);
		else if(col==4) return Float.toString(this.d_price);

		else return "";
	}
	
	public void setGoodsID(int goodsid){
		this.goods_id=goodsid;
	}
	public int getGoodsID(){
		return goods_id;
	}
	public void setGoodsName(String goodsname){
		this.goods_name=goodsname;
	}
	public String getGoodsName(){
		return goods_name;
	}
	public void setGoodsClassId(int goodsname){
		this.goods_class_id=goodsname;
	}
	public int  getGoodsClassId(){
		return goods_class_id;
	}
	

	public void setPrice(float goodsname){
		this.price=goodsname;
	}
	public float getPrice(){
		return price;
	}
		
	public void setDPrice(float goodsname){
		this.d_price=goodsname;
	}
	public float getDPrice(){
		return d_price;
	}
	
	public void setStock(int goodsid){
		this.stock=goodsid;
	}
	public int getStock(){
		return stock;
	}
	public void setSales(int goodsid){
		this.sales=goodsid;
	}
	public int getSales(){
		return sales;
	}
}
