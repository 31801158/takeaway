package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JOptionPane;

import take_away_assistant.util;
import take_away_assistant.Itf.IOrdersManager;
import take_away_assistant.bean.BeanOrders;
import take_away_assistant.bean.BeanShop;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmMain;
import take_away_assistant.ui.FrmOrders;
import take_away_assistant.ui.FrmSTicket;
import take_away_assistant.ui.FrmShowcart;

public class ExampleOrdersManager implements IOrdersManager {

	@Override
	public List<BeanOrders> loadOrders() throws BaseException {
		List<BeanOrders> result=new ArrayList<BeanOrders>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select order_id,shop_id,customer_id,rider_id,"
					+ "original_price,final_price,full_redution_id,ticket_id,"
					+ "order_time,require_arrive_time,address_id,order_condition,ifcomment"
					+ " from goods_order where customer_id=? order by order_id";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, BeanUser.currentLoginUser.getUser_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				BeanOrders p=new BeanOrders();
				p.setOrder_id(rs.getInt(1));
				p.setShop_id(rs.getInt(2));
				p.setCustomer_id(rs.getInt(3));
				p.setRider_id(rs.getInt(4));
				p.setOriginal_price(rs.getFloat(5));
				p.setFinal_price(rs.getFloat(6));
				p.setFull_redution_id(rs.getInt(7));
				p.setTicket_id(rs.getInt(8));
				p.setOrder_time(rs.getTimestamp(9));
				p.setrequire_arrive_time(rs.getTimestamp(10));
				p.setAddress_id(rs.getInt(11));
				p.setOrder_condition(rs.getString(12));
				p.setIfcomment(rs.getString(13));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public void deleteOrders(BeanOrders orders) throws BaseException {
		int order_id=orders.getOrder_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="select order_condition from goods_order where order_id="+order_id;//�鿴�Ƿ����ɾ���������ڲ����򲻿���ɾ
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getString(1).equals("��������")||rs.getString(1).equals("��ʱ")){
					rs.close();
					st.close();
					throw new BusinessException("����δ��ɣ�������ɾ����");
				}
			}
			rs.close();
			
			//������ɾ���˵�
			sql="select customer_id from goods_order where order_id="+order_id;
			rs=st.executeQuery(sql);
			int customer_id;
			if(rs.next()){
				customer_id=rs.getInt(1);
			}
			else {
				rs.close();
				st.close();
				throw new BusinessException("�ö���������");
			}
			rs.close();
			if(BeanUser.currentLoginUser.getUser_id()!=customer_id){
				st.close();
				throw new BusinessException("����ɾ�����˵Ķ���");
			}
			
			
			sql="delete from order_detil where order_id="+order_id;
			st.execute(sql);
			sql="delete from goods_order where order_id="+order_id;
			st.execute(sql);

			st.close();
			JOptionPane.showMessageDialog(null, "ɾ���ɹ���");
			
			conn.commit();
			
			return;
		}catch(BaseException e){
			try {
				conn.rollback();
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			throw e;
			
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
		
	}

	@Override
	public void showAllOrders() throws BaseException {
		loadOrders();
	}

	@Override
	public int insert(int shop_id, int customer_id, String ticket_id,
			String require_time, String address) throws BaseException {
		
		int order_id=0;
		int full_id=0;
		int full_money;
		int redution_money = 0;
		float omoney=0;
		float dprice=0;
		float fmoney=0;
		int ticket_money=0;
		int rider_id=0;
		
		List<Integer> riderlist=new ArrayList<Integer>();
		List<Float> pricelist=new ArrayList<Float>();
		List<Float> dpricelist=new ArrayList<Float>();
		List<Integer> goodlist=new ArrayList<Integer>();
		List<Integer> goodcount=new ArrayList<Integer>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			
			
			if(ticket_id==null||"".equals(ticket_id)){//δ����
				
			}
			else{
				
			if(util.ticketManager.ifExist(ticket_id)==0){
				JOptionPane.showMessageDialog(null,  "��û�������Ż�ȯŶ��");
			return 0;}
//			else{//�����Ż�ȯ
//			
//			util.ticketManager.delete1(ticket_id);
//			FrmSTicket.allTicket=util.ticketManager.loadTicket();
//			}
			}
			String sql="select max(order_id) from goods_order";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				order_id=rs.getInt(1);
			}order_id=order_id+1;
			
			
			sql="select rider_id from rider_msg";//����������͵�����
			rs=st.executeQuery(sql);
			while(rs.next()){
				riderlist.add(rs.getInt(1));
			}
			Random random = new Random();
		    int s = random.nextInt(riderlist.size()-1) % (riderlist.size()-1 - 0 + 1) + 0;
		    
			
			
			sql="select 1 from address where address_id="+Integer.parseInt(address)+" and customer_id="+BeanUser.currentLoginUser.getUser_id();
			rs=st.executeQuery(sql);
			if(!rs.next()){
				JOptionPane.showMessageDialog(null, "�õ�ַ�����ڣ�", "����",JOptionPane.INFORMATION_MESSAGE);
				return 0;
			}
			if(ticket_id==null||"".equals(ticket_id))
				ticket_money=0;
			else{
				sql="SELECT ticket_money from ticket where ticket_id="+ticket_id;
				ticket_money=rs.getInt(1);
			}
			if(FrmShowcart.allcart==null){
				JOptionPane.showMessageDialog(null, "���Ȳ鿴��Ĺ��ﳵ��");
				return 0;}
			for(int i=0;i<FrmShowcart.allcart.size();i++){//ѡ�����ﳵ�� ���̵����Ʒ
				if(FrmShowcart.allcart.get(i).getcustomer_id()==BeanUser.currentLoginUser.getUser_id()&&FrmShowcart.allcart.get(i).getshop_id()==FrmMain.curShop.getShop_id()){
					goodlist.add(FrmShowcart.allcart.get(i).getgoods_id());//��Ʒ���
					goodcount.add(FrmShowcart.allcart.get(i).getcount());//ÿ����Ʒ������
					dpricelist.add(FrmShowcart.allcart.get(i).getd_price());
					pricelist.add(FrmShowcart.allcart.get(i).getprice());
				}
			}
			for(int i=0;i<goodlist.size();i++){
				sql="select stock from relation_shopandgoods  where goods_id="+goodlist.get(i)+" and shop_id="+shop_id;
				rs=st.executeQuery(sql);
				while(rs.next()){
				if(rs.getInt(1)<goodcount.get(i)){
					JOptionPane.showMessageDialog(null, "��治��", "����",JOptionPane.INFORMATION_MESSAGE);
					return 0;
				}
				}
			}
			
			for(int i=0;i<goodlist.size();i++){
				sql="select price,d_price from goods_msg where goods_id="+goodlist.get(i);
				rs=st.executeQuery(sql);
				while(rs.next()){
				omoney=omoney+rs.getFloat(1)*goodcount.get(i);
				dprice=dprice+rs.getFloat(2)*goodcount.get(i);
				}
			}//����� ԭ�� ���ڹ�����Żݼ۸�
			
			
			sql="SELECT full_redution.full_redution_id,full_money,redution_money,use_with_ticket"
					+ " from relation_shop_and_fullredution,full_redution"
					+ " where shop_id="+shop_id
					+ " and relation_shop_and_fullredution.full_redution_id=full_redution.full_redution_id";
			rs=st.executeQuery(sql);//��ѯ����
			while(rs.next()){
				if(rs.getInt(4)==1&&omoney>=rs.getInt(2)){//�����Ż�ȯͬ�� �����ܽ���㹻���� 
					full_id=rs.getInt(1);full_money=rs.getInt(2);redution_money=rs.getInt(3);
					break;
				}
			}
			
			float d=dprice-redution_money-ticket_money;
//			("+order_id+","+shop_id+","+customer_id+
//					","+1+","+omoney+","++"?,?,?,?,?,?,? ,'��������', '������')";
			Timestamp order=new Timestamp(System.currentTimeMillis()); 
			Timestamp require=new Timestamp(System.currentTimeMillis()); 
	          
			SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateStr = dateformat.format(require);
			
			order=Timestamp.valueOf(dateStr);
	        require=Timestamp.valueOf(require_time); 
	        if(ticket_id==null||"".equals(ticket_id)){
	        	if(full_id!=0)
	        		sql="INSERT INTO `take1`.`goods_order` (`order_id`, `shop_id`, `customer_id`, `rider_id`,"
						+ " `original_price`, `final_price`, `full_redution_id`, `order_time`,"
						+ " `require_arrive_time`, `address_id`, `order_condition`, `ifcomment`) "
						+ "VALUES ("+order_id+","+shop_id+","+customer_id+
						","+riderlist.get(s)+","+omoney+","+d+","+full_id+",'"+order+"','"+require+"',"+Integer.parseInt(address)+" ,'��������', '������')";
	        	else
	        		sql="INSERT INTO `take1`.`goods_order` (`order_id`, `shop_id`, `customer_id`, `rider_id`,"
							+ " `original_price`, `final_price`, `order_time`,"
							+ " `require_arrive_time`, `address_id`, `order_condition`, `ifcomment`) "
							+ "VALUES ("+order_id+","+shop_id+","+customer_id+
							","+riderlist.get(s)+","+omoney+","+d+",'"+order+"','"+require+"',"+Integer.parseInt(address)+" ,'��������', '������')";
	        }
	        else{
	        	if(full_id!=0)
	        		sql="INSERT INTO `take1`.`goods_order` (`order_id`, `shop_id`, `customer_id`, `rider_id`,"
					+ " `original_price`, `final_price`, `full_redution_id`, `ticket_id`, `order_time`,"
					+ " `require_arrive_time`, `address_id`, `order_condition`, `ifcomment`) "
					+ "VALUES ("+order_id+","+shop_id+","+customer_id+
					","+riderlist.get(s)+","+omoney+","+d+","+full_id+","+Integer.parseInt(ticket_id)+",'"+order+"','"+require+"',"+Integer.parseInt(address)+" ,'��������', '������')";
	        	else
	        		sql="INSERT INTO `take1`.`goods_order` (`order_id`, `shop_id`, `customer_id`, `rider_id`,"
	    					+ " `original_price`, `final_price`, `ticket_id`, `order_time`,"
	    					+ " `require_arrive_time`, `address_id`, `order_condition`, `ifcomment`) "
	    					+ "VALUES ("+order_id+","+shop_id+","+customer_id+
	    					","+riderlist.get(s)+","+omoney+","+d+","+Integer.parseInt(ticket_id)+",'"+order+"','"+require+"',"+Integer.parseInt(address)+" ,'��������', '������')";
	        }
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//			pst.setInt(1,order_id);
//			System.out.println(order_id);
//			pst.setInt(2, shop_id);
//			System.out.println(shop_id);
//			pst.setInt(3, customer_id);
//			pst.setInt(4, 1);
//			pst.setFloat(5, omoney);
//			pst.setFloat(6, d);//ԭ�۴ﵽ����   �Żݼ۸��ȥ����  ��ȥ�Ż�ȯ
//			pst.setInt(7, full_id);
//			if(ticket_id==null||"".equals(ticket_id))
//				pst.setInt(8,0);
//			
//			else pst.setInt(8, Integer.parseInt(ticket_id));
//			Timestamp order=new Timestamp(System.currentTimeMillis()); 
//			Timestamp require=new Timestamp(System.currentTimeMillis()); 
//	           
//	        require=Timestamp.valueOf(require_time); 
//			pst.setTimestamp(9, order);
//			pst.setTimestamp(10, require);
//			pst.setInt(11, Integer.parseInt(address));
			pst.execute(sql);
			
			//�������������
			
			//����Ϊ���������
			for(int i=0;i<goodlist.size();i++){
			sql="INSERT INTO `take1`.`order_detil` (`order_id`, `goods_id`, `order_onegoods_count`, `price`, `d_price`)"
					+ " VALUES ("+order_id+","+goodlist.get(i)+","+goodcount.get(i)+","+pricelist.get(i)+","+dpricelist.get(i)+")";
			pst=conn.prepareStatement(sql);
//			pst.setInt(1, order_id);
//			pst.setInt(2, goodlist.get(i));
//			pst.setInt(3, goodcount.get(i));
//			pst.setFloat(4, pricelist.get(i));
//			pst.setFloat(5, dpricelist.get(i));
//			System.out.println(sql);
			pst.execute(sql);
			
			}
			
			//��������
			sql="select ticket_id from relation_shopandticket where shop_id="+shop_id;
			rs=st.executeQuery(sql);
			while(rs.next()){
				int tid=rs.getInt(1);//Ҫ�����Ż�ȯ���
				sql="select * from customer_getticket_process where shop_id="+shop_id+" and customer_id="+customer_id+" and ticket_id="+tid;

			rs=st.executeQuery(sql);
			
			if(rs.next()){//���������Ѵ����Ż�ȯ
				sql="update customer_getticket_process"
						+ " set get_ticket_already=get_ticket_already+1"
						+ " where shop_id="+shop_id+" and customer_id="+customer_id+"and ticket_id="+tid;
				st.execute(sql);
			}
			else{//������
				sql="select get_ticket_require from ticket where ticket_id="+tid;
				int a;
				if(rs.next()){
					a=rs.getInt(1);
					sql="INSERT INTO `take1`.`customer_getticket_process` (`customer_id`, `shop_id`, `ticket_id`, `get_ticket_require`, `get_ticket_already`)"
							+ " VALUES ("+customer_id+", "+shop_id+", "+tid+","+a+", 1)";
					st.execute(sql);
				}
				
			}

			
			//����+1��  �鿴��������already�Ƿ����reuqire
			sql="select get_ticket_already,get_ticket_require from customer_getticket_process where shop_id="+shop_id+" and customer_id="+customer_id+" and ticket_id="+tid;
			rs=st.executeQuery(sql);
			if(rs.next()){//�Ż�ȯ+1
				if(rs.getInt(1)>=rs.getInt(2)){
					sql="delete from customer_getticket_process where shop_id="+shop_id+" and customer_id="+customer_id+" and ticket_id="+tid;
					st.execute(sql);

					sql="select ticket_money,get_ticket_require,ticket_start_date,ticket_end_date from ticket where ticket_id="+tid;
					rs=st.executeQuery(sql);
					sql="select 1 from have_ticket where ticket_id="+tid+"and shop_id="+shop_id+" and customer_id="+customer_id;
					if(rs.next()){//�Ѵ���+1
						sql="update have_ticket set ticket_count=ticket_count+1 where ticket_id="+tid+" and shop_id="+shop_id+" and customer_id="+customer_id;
						st.execute(sql);
					}
					else {//������insert
						sql="INSERT INTO `take1`.`have_ticket` (`customer_id`, `shop_id`, `ticket_id`, `ticket_count`, `ticket_money`, `ticket_deadline`) "
							+ "VALUES ("+customer_id+","+shop_id+","+ticket_id+","+1+","+rs.getInt(1)+",'"+rs.getTimestamp(4)+"')";
					 st.execute(sql);}
				}
					
					
			}
			break;
			}
			
			
			//�޸Ŀ��  �޸Ĺ��ﳵ
			for(int i=0;i<goodlist.size();i++){			
				sql="update relation_shopandgoods set stock=stock-"+goodcount.get(i)+" where shop_id="+shop_id+" and goods_id="+goodlist.get(i);
				st.execute(sql);
				sql="delete from cart where shop_id="+shop_id;
				st.execute(sql);
			}
			
			
			pst.close();
			st.close();

			if(ticket_id!=null&&!("".equals(ticket_id))){
			util.ticketManager.delete1(ticket_id);
			FrmSTicket.allTicket=util.ticketManager.loadTicket();
			}
			conn.commit();
			
			
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return 1;
		
	}

	@Override
	public void receiveOrders(BeanOrders beanOrders) throws BaseException {
		int order_id=beanOrders.getOrder_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			if(BeanUser.currentLoginUser.getUser_id()!=beanOrders.getCustomer_id()){
				throw new BusinessException("����ȷ�����˵Ķ���");
			}
			
			
			String sql="update goods_order set order_condition='���ʹ�' where order_id="+order_id;
			java.sql.Statement st=conn.createStatement();
			st.execute(sql);
			
			st.close();
			JOptionPane.showMessageDialog(null, "�ջ��ɹ���");
			
			return;
		}catch (SQLException e) {
			
			throw new DbException(e);
			
		} finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
	}

	
}
