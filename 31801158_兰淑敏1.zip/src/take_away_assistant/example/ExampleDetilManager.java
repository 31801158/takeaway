package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import take_away_assistant.Itf.IDetilManager;
import take_away_assistant.bean.BeanOrderDetil;
import take_away_assistant.bean.BeanOrders;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;

public class ExampleDetilManager implements IDetilManager{

	@Override
	public List<BeanOrderDetil> loadDetil(BeanOrders order)
			throws BaseException {
		List<BeanOrderDetil> result=new ArrayList<BeanOrderDetil>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select * from order_detil where order_id=? order by order_id";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, order.getOrder_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanOrderDetil p=new BeanOrderDetil();
				p.setorder_id(rs.getInt(1));
				p.setgoods_id(rs.getInt(2));
				p.setcount(rs.getInt(3));
				p.setprice(rs.getFloat(4));
				p.setd_price(rs.getFloat(5));
				
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

}
