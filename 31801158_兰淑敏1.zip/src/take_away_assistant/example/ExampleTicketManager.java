package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import take_away_assistant.Itf.ITicketManager;
import take_away_assistant.bean.BeanClass;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmMain;
import take_away_assistant.ui.FrmManager;

public class ExampleTicketManager implements ITicketManager{//�û��鿴

	@Override
	public List<BeanTicket> loadTicket() throws BaseException {
		List<BeanTicket> result=new ArrayList<BeanTicket>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select shop_id,ticket_id,ticket_count,ticket_money,ticket_deadline "
					+ "from have_ticket where customer_id=? order by ticket_id";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, BeanUser.currentLoginUser.getUser_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanTicket p =new BeanTicket();
				p.setcustomer_id(BeanUser.currentLoginUser.getUser_id());
				p.setshop_id(rs.getInt(1));
				p.setticket_id(rs.getInt(2));
				p.setticket_count(rs.getInt(3));
				p.setticket_money(rs.getFloat(4));
				p.setend_date(rs.getTimestamp(5));
				result.add(p);

			}
			rs.close();
			pst.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	@Override
	public List<BeanTicket> loadTicket1() throws BaseException {//����Ա�鿴
		List<BeanTicket> result=new ArrayList<BeanTicket>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select ticket.ticket_id,ticket_money,get_ticket_require,"
					+ "ticket_start_date,ticket_end_date,shop_msg.shop_id"
					+ " from shop_msg,ticket,relation_shopandticket"
					+ " WHERE shop_msg.shop_id=relation_shopandticket.shop_id"
					+ " and relation_shopandticket.ticket_id=ticket.ticket_id order by ticket_id";
//			String sql="select ticket_id,ticket_money,get_ticket_require,ticket_start_date,ticket_end_date "
//					+ "from ticket order by ticket_id";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanTicket p =new BeanTicket();
				
				p.setticket_id(rs.getInt(1));
				p.setticket_money(rs.getFloat(2));
				p.setGet_ticket_require(rs.getInt(3));
				p.setstart_date(rs.getTimestamp(4));
				p.setend_date(rs.getTimestamp(5));
				p.setshop_id(rs.getInt(6));
				result.add(p);
			}
			sql="select ticket_id,ticket_money,get_ticket_require,ticket_start_date,ticket_end_date"
					+ " from ticket"
					+ " where ticket_id not in("
					+ "select DISTINCT ticket.ticket_id"
					+ " from shop_msg,ticket,relation_shopandticket"
					+ " WHERE shop_msg.shop_id=relation_shopandticket.shop_id"
					+ " and relation_shopandticket.ticket_id=ticket.ticket_id order by ticket_id)"
					+ " order by ticket_id";
			st=conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				BeanTicket p =new BeanTicket();
				
				p.setticket_id(rs.getInt(1));
				p.setticket_money(rs.getFloat(2));
				p.setGet_ticket_require(rs.getInt(3));
				p.setstart_date(rs.getTimestamp(4));
				p.setend_date(rs.getTimestamp(5));
				p.setshop_id(0);
				result.add(p);
;
			}
			rs.close();
			st.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	@Override
	public void insert(String money, String require, String start, String end)
			throws BaseException {
		// TODO Auto-generated method stub
		if(money==null || "".equals(money))throw new BusinessException("�Żݽ���Ϊ��!");
		if(require==null || "".equals(require))throw new BusinessException("����Ҫ��������Ϊ��!");
		if(start==null || "".equals(start))throw new BusinessException("��ʼʱ�䲻��Ϊ��!");
		if(end==null || "".equals(end))throw new BusinessException("����ʱ�䲻��Ϊ��!");
		int ticket_id=0;
		float money1=Float.parseFloat(money);
		int require1=Integer.parseInt(require);
		
		Timestamp start1=new Timestamp(System.currentTimeMillis()); 

		Timestamp end1=new Timestamp(System.currentTimeMillis()); 
		 
        
        start1 = Timestamp.valueOf(start);   
        
        end1=Timestamp.valueOf(end);  
        
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT max(ticket_id) from ticket";
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				ticket_id=rs.getInt(1);//��ȡid
			}
			ticket_id=ticket_id+1;
			rs.close();
			st.close();
			
			sql="INSERT INTO `take1`.`ticket` (`ticket_id`, `ticket_money`, `get_ticket_require`, `ticket_start_date`, `ticket_end_date`) "
					+ "VALUES (?,?,?,?,?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, ticket_id);
			pst.setFloat(2, money1);
			pst.setInt(3, require1);
			pst.setTimestamp(4, start1);
			pst.setTimestamp(5, end1);
			
			pst.execute();
			JOptionPane.showMessageDialog(null,  "�����ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
	@Override
	public void update(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("����Ϊ��!");
		int ticket_id=FrmManager.curticket.getticket_id();
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql;
			java.sql.PreparedStatement pst;
			java.sql.ResultSet rs;
			java.sql.Statement st;
			if(FrmManager.rightcolumn==1){//money
				int a=Integer.parseInt(text);
				sql="update ticket set ticket_money="+a+" WHERE ticket_id="+ticket_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curticket.setticket_money(a);
				
			}
			
			else if(FrmManager.rightcolumn==2){//����
				int a=Integer.parseInt(text);
				sql="update ticket set get_ticket_require="+a+" WHERE ticket_id="+ticket_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curticket.setGet_ticket_require(a);
			}
			else if(FrmManager.rightcolumn==3){//��ʼ
				Timestamp start1=new Timestamp(System.currentTimeMillis());  
		        start1 = Timestamp.valueOf(text);   
				sql="update ticket set start_date='"+start1+"' WHERE ticket_id="+ticket_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curticket.setstart_date(start1);
			}
			else if(FrmManager.rightcolumn==3){//��ʼ
				Timestamp end1=new Timestamp(System.currentTimeMillis()); 
		        end1=Timestamp.valueOf(text); 
				sql="update ticket set end_date='"+end1+"' WHERE ticket_id="+ticket_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curticket.setstart_date(end1);
			}
			
			JOptionPane.showMessageDialog(null,  "�޸ĳɹ�����ˢ��");
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		} finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	@Override
	public void delete(BeanTicket beanTicket) throws BaseException {
		int ticket_id=beanTicket.getticket_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			if(beanTicket.getshop_id()==0){//ɾ���Ż�ȯ
			String sql="SELECT 1 from goods_order where ticket_id="+ticket_id;
			java.sql.Statement st=conn.createStatement();
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0){
					rs.close();
					st.close();
					throw new BusinessException("���ж���ʹ�ù����Ż�ȯ��������ɾ����");
				}
				rs.close();
			}
			
			
			
			else{
			sql="delete from customer_getticket_process where ticket_id="+ticket_id;
			st.execute(sql);
			
			sql="delete from customer_getticket_process where ticket_id="+ticket_id;
			st.execute(sql);
			sql="delete from have_ticket where ticket_id="+ticket_id;
			st.execute(sql);
			
			sql="delete from relation_customer_and_haveticket where ticket_id="+ticket_id;
			st.execute(sql);
			
			sql="delete from relation_shopandticket where ticket_id="+ticket_id;
			st.execute(sql);
			sql="delete from ticket where ticket_id="+ticket_id;
			st.execute(sql);
			}
			
			}
			
			
			else{//ɾ���̼ҵ�����   ���������Դ��ڸ�������
				String sql="delete from relation_shopandticket where ticket_id="+ticket_id+" and shop_id="+beanTicket.getshop_id();
				java.sql.Statement st=conn.createStatement();
				st.execute(sql);
				
			}
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
			
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}
	@Override
	public int ifExist(String id) throws BaseException {
		if(id==null || "".equals(id))throw new BusinessException("�Ż�ȯ��Ų���Ϊ��!");

		int tid=Integer.parseInt(id); 
        
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT ticket_id from have_ticket where ticket_id="
			+tid+" and customer_id="+BeanUser.currentLoginUser.getUser_id()
			+" and shop_id="+FrmMain.curShop.getShop_id();
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(!rs.next()){
				
				return 0;
			}
			rs.close();
			st.close();
			return 1;
		}catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}
	@Override
	public void delete1(String tid) throws BaseException {//�µ�ʱɾ��ӵ�е��Ż�ȯ
		
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="delete from have_ticket where ticket_id="+tid+" and customer_id="+BeanUser.currentLoginUser.getUser_id()+" and shop_id="+FrmMain.curShop.getShop_id();
			java.sql.Statement st=conn.createStatement();
			st.execute(sql);
			st.close();
			
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}
	@Override
	public List<BeanTicket> loadTicketProcess() throws BaseException {
		List<BeanTicket> result=new ArrayList<BeanTicket>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT * from customer_getticket_process where customer_id="+BeanUser.currentLoginUser.getUser_id();
//			String sql="select ticket_id,ticket_money,get_ticket_require,ticket_start_date,ticket_end_date "
//					+ "from ticket order by ticket_id";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanTicket p =new BeanTicket();
				p.setcustomer_id(rs.getInt(1));
				p.setshop_id(rs.getInt(2));
				p.setticket_id(rs.getInt(3));
				p.setGet_ticket_require(rs.getInt(4));
				p.setget_ticket_already(rs.getInt(5));
				
				result.add(p);
			}
			
			rs.close();
			st.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	@Override
	public void addtoshop(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("�Ż�ȯ��Ų���Ϊ��!");

		int ticket_id=Integer.parseInt(text);

		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT ticket_id from ticket where ticket_id="+ticket_id;
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(!rs.next()){
				JOptionPane.showMessageDialog(null, "�Ż�ȯ�����ڣ�", "����",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			
			sql="SELECT ticket_id from relation_shopandticket where ticket_id="+ticket_id+" and shop_id="+FrmManager.curShop.getShop_id();
			rs=st.executeQuery(sql);
			if(rs.next()){
				JOptionPane.showMessageDialog(null, "�Ż�ȯ�Ѵ��ڣ�", "����",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			sql="INSERT INTO `take1`.`relation_shopandticket` (`ticket_id`, `shop_id`) VALUES ("+ticket_id+", "+FrmManager.curShop.getShop_id()+")";
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			st.execute(sql);
			st.close();
			rs.close();
			JOptionPane.showMessageDialog(null,  "���ӳɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}
	@Override
	public void deletefromshop(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("�Ż�ȯ��Ų���Ϊ��!");

		int ticket_id=Integer.parseInt(text);
		int shop_id=FrmManager.curShop.getShop_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT ticket_id from relation_shopandticket where ticket_id="+ticket_id+" and shop_id="+shop_id;
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(!rs.next()){
				JOptionPane.showMessageDialog(null, "���̵겻���������Ż�ȯ��", "����",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			rs.close();
			
			
			sql="delete from relation_shopandticket where shop_id="+shop_id+" and ticket_id="+ticket_id;
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			st.execute(sql);
			st.close();
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}
	
}
