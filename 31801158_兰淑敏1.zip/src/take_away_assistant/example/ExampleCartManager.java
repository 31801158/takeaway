package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import take_away_assistant.Itf.ICartManager;
import take_away_assistant.Itf.IFullManager;
import take_away_assistant.bean.BeanCart;
import take_away_assistant.bean.BeanFull;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmShowcart;

public class ExampleCartManager implements ICartManager {

	@Override
	public List<BeanCart> loadCart() throws BaseException {
		List<BeanCart> result=new ArrayList<BeanCart>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select * from cart where customer_id="+BeanUser.currentLoginUser.getUser_id();
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanCart p =new BeanCart();
				p.setshop_id(rs.getInt(1));
				p.setclass_id(rs.getInt(2));
				p.setgoods_id(rs.getInt(3));
				p.setcustomer_id(rs.getInt(4));
				p.setcount(rs.getInt(5));
				result.add(p);
			}
			
			rs.close();
			st.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public void remove(BeanCart beanCart) throws BaseException {
		int shop_id=beanCart.getshop_id();
		int customer_id=beanCart.getcustomer_id();
		int goods_id=beanCart.getgoods_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="DELETE from cart where shop_id="+shop_id+" and goods_id="+goods_id+" and customer_id="+customer_id;
			java.sql.Statement st=conn.createStatement();
			st.execute(sql);
			System.out.println(sql);
			st.close();
			if(BeanUser.currentLoginUser.getUser_id()!=customer_id){
				st.close();
				throw new BusinessException("����ɾ�����˵Ĺ��ﳵ");
			}
			conn.commit();
		}catch(Exception ex){
			ex.printStackTrace();
			throw new DbException(ex);
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

}
