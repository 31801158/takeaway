package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;





import take_away_assistant.Itf.IFullManager;
import take_away_assistant.bean.BeanFull;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmManager;

public class ExampleFullManager implements IFullManager{

	@Override
	public List<BeanFull> loadFull() throws BaseException {
		List<BeanFull> result=new ArrayList<BeanFull>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select full_redution.full_redution_id,full_money,redution_money,use_with_ticket,shop_id"
					+ " from full_redution,relation_shop_and_fullredution"
					+ " where full_redution.full_redution_id=relation_shop_and_fullredution.full_redution_id"
					+ " order by full_redution.full_redution_id";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanFull p =new BeanFull();
				p.setfull_redution_id(rs.getInt(1));
				p.setfull_momey(rs.getFloat(2));
				p.setredution_money(rs.getInt(3));
				p.setuse_with_ticket(rs.getInt(4));
				p.setshop_id(rs.getInt(5));
				result.add(p);
			}
			sql="select full_redution.full_redution_id,full_money,redution_money,use_with_ticket"
					+ " from full_redution"
					+ " where full_redution_id not in"
					+ "(select full_redution_id from relation_shop_and_fullredution)"
					+ " order by full_redution.full_redution_id";
			rs=st.executeQuery(sql);
			while(rs.next()){
				BeanFull p =new BeanFull();
				p.setfull_redution_id(rs.getInt(1));
				p.setfull_momey(rs.getFloat(2));
				p.setredution_money(rs.getInt(3));
				p.setuse_with_ticket(rs.getInt(4));
				p.setshop_id(0);
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;

	}

	@Override
	public void insert(String full, String redution, String with)
			throws BaseException {
		if(full==null || "".equals(full))throw new BusinessException("������Ϊ��!");
		if(redution==null || "".equals(redution))throw new BusinessException("������Ϊ��!");
		if(with==null || "".equals(with))throw new BusinessException("�Ƿ�ͬ������Ϊ��!");
		int full_id=0;
		int full1=Integer.parseInt(full);
		int redution1=Integer.parseInt(redution);
		int with1=Integer.parseInt(with);
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT max(full_redution_id) from full_redution";
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				full_id=rs.getInt(1)+1;//��ȡshop_id
			}
			rs.close();
			st.close();
			
			sql="INSERT INTO `take1`.`full_redution` (`full_redution_id`, `full_money`, `redution_money`, `use_with_ticket`) "
					+ "VALUES (?,?,?,?);";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, full_id);
			pst.setInt(2, full1);
			pst.setInt(3, redution1);
			pst.setInt(4, with1);
			
			pst.execute();
			BeanFull f = new BeanFull();
			f.setfull_redution_id(full_id);
			f.setfull_momey(full1);
			f.setredution_money(redution1);
			f.setuse_with_ticket(with1);
			FrmManager.allfull.add(f);
			JOptionPane.showMessageDialog(null,  "�����ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void update(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("����Ϊ��!");
		int full_id=FrmManager.curfull.getfull_redution_id();
		int a=Integer.parseInt(text);
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql;
			java.sql.PreparedStatement pst;
			java.sql.ResultSet rs;
			java.sql.Statement st;
			if(FrmManager.rightcolumn==1){//��
				sql="update full_redution set full_money="+a+" WHERE full_redution_id="+full_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curfull.setfull_momey(a);
				
			}
			
			else if(FrmManager.rightcolumn==2){//��
				sql="update full_redution set redution_money="+a+" WHERE full_redution_id="+full_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curfull.setredution_money(a);
			}
			else if(FrmManager.rightcolumn==3){//ͬ��
				sql="update full_redution set use_with_ticket="+a+" WHERE full_redution_id="+full_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curfull.setuse_with_ticket(a);
			}
			
			JOptionPane.showMessageDialog(null,  "�޸ĳɹ�����ˢ��");
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		} finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void delete(BeanFull beanFull) throws BaseException {
		int full_id=beanFull.getfull_redution_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			if(beanFull.getshop_id()==0){//ɾ���Ż�ȯ
			String sql="SELECT 1 from goods_order where full_redution_id="+full_id;
			java.sql.Statement st=conn.createStatement();
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0){
					rs.close();
					st.close();
					throw new BusinessException("���ж���ʹ�ù���������������ɾ����");
				}
			}
			rs.close();
			
			sql="delete from relation_shop_and_fullredution where full_redution_id="+full_id;
			st.execute(sql);
			sql="delete from full_redution where full_redution_id="+full_id;
			st.execute(sql);
			}
			else{//ɾ���̼ҵ�����   ���������Դ��ڸ�������
				String sql="delete from relation_shop_and_fullredution where full_redution_id="+full_id+" and shop_id="+beanFull.getshop_id();
				java.sql.Statement st=conn.createStatement();
				st.execute(sql);
				
			}
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
			
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void deletefromshop(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("������Ų���Ϊ��!");

		int full_id=Integer.parseInt(text);
		int shop_id=FrmManager.curShop.getShop_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT full_redution_id from relation_shop_and_fullredution where full_redution_id="+full_id+" and shop_id="+shop_id;
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(!rs.next()){
				JOptionPane.showMessageDialog(null, "���̵겻��������������", "����",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			rs.close();
			
			
			sql="delete from relation_shop_and_fullredution where shop_id="+shop_id+" and full_redution_id="+full_id;
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			st.execute(sql);
			st.close();
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	
		
	}

	@Override
	public void addtoshop(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("������Ų���Ϊ��!");

		int full_id=Integer.parseInt(text);

		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT full_redution_id from full_redution where full_redution_id="+full_id;
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(!rs.next()){
				JOptionPane.showMessageDialog(null, "���������ڣ�", "����",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			rs.close();
			sql="SELECT full_redution_id from relation_shop_and_fullredution where full_redution_id="+full_id+" and shop_id="+FrmManager.curShop.getShop_id();
			rs=st.executeQuery(sql);
			if(rs.next()){
				JOptionPane.showMessageDialog(null, "�����Ѵ��ڣ�", "����",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			sql="INSERT INTO `take1`.`relation_shop_and_fullredution` (`full_redution_id`, `shop_id`)"
					+ " VALUES ("+full_id+", "+FrmManager.curShop.getShop_id()+");";
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			st.execute(sql);
			st.close();
			JOptionPane.showMessageDialog(null,  "���ӳɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}
	

}
