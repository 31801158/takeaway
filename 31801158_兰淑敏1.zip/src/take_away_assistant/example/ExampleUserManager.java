package take_away_assistant.example;

import java.awt.Frame;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import take_away_assistant.Itf.IUserManager;
import take_away_assistant.bean.BeanManager;
import take_away_assistant.bean.BeanShop;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmComMsg;
import take_away_assistant.ui.FrmManager;
import take_away_assistant.ui.FrmSMsg;


public class ExampleUserManager implements IUserManager {

	
	
	private static final String redatetime = null;

	public BeanUser reg(String name,String pwd,String pwd2) throws BaseException {
		if(name==null || "".equals(name))throw new BusinessException("�û�������Ϊ��!");
		if(pwd==null || "".equals(pwd))throw new BusinessException("���벻��Ϊ��!");
		if(!pwd.equals(pwd2)) throw new BusinessException("��������������벻һ�£�");

		Connection conn=null;
		try {
			String sql="select customer_name from customer_msg where customer_tel=?";//?ռλ��
			conn=DBUtil.getConnection();
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,name);
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){
				
				rs.close();
				pst.close();
				throw new BusinessException("�û��Ѵ���");
			}
			pst.close();
			
			sql="select max(customer_id) from customer_msg";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			int cid = 0;
			if(rs.next()){
				cid=rs.getInt(1);//��ȡcustomer_id
			}
			rs.close();
			st.close();
			
			sql="insert into customer_msg(customer_id,customer_pwd,customer_register_date,customer_name) values(?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1, cid+1);
			pst.setString(2, pwd);
			Timestamp t= new java.sql.Timestamp(System.currentTimeMillis());
			pst.setTimestamp(3,t);
			pst.setString(4, name);
			pst.execute();
			BeanUser user=new BeanUser();
			user.setRegister_time(t);
			user.setUser_id(cid+1);
			user.setPwd(pwd);
			user.setcustomer_name(name);
			rs.close();
			pst.close();
			return user;
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public BeanUser login(String name, String pwd) throws BaseException {
		if(name==null || "".equals(name))throw new BusinessException("�û�������Ϊ��!");
		if(pwd==null || "".equals(pwd))throw new BusinessException("���벻��Ϊ��!");
		
		
		
		Connection conn=null;
		try {
			
			conn=DBUtil.getConnection();
			BeanUser user=null;
			String sql="select customer_id,customer_name,customer_sex,"
					+ "customer_pwd,customer_tel,customer_mail,"
					+ "customer_city,customer_register_date,vip,"
					+ "vip_deadline from customer_msg where customer_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,name);
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){//�û�����
				if(rs.getString("customer_pwd").equals(pwd)) {//success	
					
					user=new BeanUser();
					user.setUser_id(rs.getInt(1));
					user.setcustomer_name(name);
					user.setcustomer_sex(rs.getString(3));
					user.setPwd(pwd);
					user.setcustomer_tel(rs.getString(5));
					user.setcustomer_mail(rs.getString(6));
					user.setcustomer_city(rs.getString(7));
					user.setRegister_time(rs.getTimestamp(8));
					user.setVip(rs.getString(9));
					user.setvip_deadline(rs.getString(10));
					rs.close();
					pst.close();
					return user;
				}
				else{
					throw new BusinessException("�û��������벻��ȷ��");
				}		
			}
			else throw new BusinessException("�û��������ڣ�");
			
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	
	public BeanManager login2(String name, String pwd) throws BaseException {
		if(name==null || "".equals(name))throw new BusinessException("�û�������Ϊ��!");
		if(pwd==null || "".equals(pwd))throw new BusinessException("���벻��Ϊ��!");
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			BeanManager manager=null;
			String sql="select m_id,m_name,m_pwd"
					+ " from manager_msg where m_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,name);
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){//����Ա����
				if(rs.getString("m_pwd").equals(pwd)) {//success	
					
					manager=new BeanManager();
					manager.setm_id(rs.getInt(1));
					manager.setm_name(rs.getString(2));
					manager.setPwd(rs.getString(3));
					rs.close();
					pst.close();
					return manager;
				}
				else{
					throw new BusinessException("�û��������벻��ȷ��");
				}		
			}
			else throw new BusinessException("�û��������ڣ�");
		} catch (SQLException e) {	
			throw new DbException(e);
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
			
		
	}
	@Override
	public void changePwd(BeanUser user, String oldPwd, String newPwd,
			String newPwd2) throws BaseException {

		if(oldPwd==null || "".equals(oldPwd))throw new BusinessException("ԭ���벻��Ϊ��!");
		if(newPwd==null || "".equals(newPwd))throw new BusinessException("�����벻��Ϊ��!");
		if(newPwd2==null || "".equals(newPwd2))throw new BusinessException("�����벻��Ϊ��!");
		if(!newPwd.equals(newPwd2)) throw new BusinessException("�������벻һ�£�");
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select customer_pwd from customer_msg where customer_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,user.getcustomer_name());
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){
				if(!rs.getString("customer_pwd").equals(oldPwd)){
					throw new BusinessException("ԭ���벻��ȷ��");
				}
			
			
			else{
				
				//String sql1="update tbl_user set user_Pwd=?,register_time=? where user_id=?;";
				sql="update customer_msg set customer_Pwd=? where customer_name=?";
				pst=conn.prepareStatement(sql);
				pst.setString(1,newPwd);
				//pst.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
				pst.setString(2, user.getcustomer_name());
				pst.execute();//�޸�
				//user.setRegister_time(new Date());
				user.setPwd(newPwd2);
				user.setUser_id(user.getUser_id());
				rs.close();
				pst.close();
				JOptionPane.showMessageDialog(null,"�޸ĳɹ�");
			}
			}
			
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	
		
	}

	@Override
	public void comMsg(BeanUser user,String edtName,String edtSex,String edtCity,
			String edtMail,String edtTel) throws BaseException {
		if((edtName==null || "".equals(edtName))&&Array.getInt(FrmComMsg.l, 0)==1)throw new BusinessException("��������Ϊ��!");
		if((edtSex==null || "".equals(edtSex))&&Array.getInt(FrmComMsg.l, 1)==1)throw new BusinessException("�Ա���Ϊ��!");
		if((edtMail==null || "".equals(edtMail))&&Array.getInt(FrmComMsg.l, 2)==1)throw new BusinessException("���䲻��Ϊ��!");
		if((edtCity==null || "".equals(edtCity))&&Array.getInt(FrmComMsg.l, 3)==1)throw new BusinessException("���в���Ϊ��!");
		if((edtTel==null || "".equals(edtTel))&&Array.getInt(FrmComMsg.l, 4)==1)throw new BusinessException("�ֻ����벻��Ϊ��!");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="update customer_msg"
					+ " set customer_name=?,customer_sex=?,customer_mail=?,"
					+ "customer_city=?,customer_tel=? "
					+ "where customer_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,edtName);
			pst.setString(2,edtSex);
			pst.setString(3,edtMail);
			pst.setString(4,edtCity);
			pst.setString(5,edtTel);
			pst.setString(6,user.getcustomer_name());
			pst.execute();
			BeanUser.currentLoginUser.setcustomer_name(edtName);
			BeanUser.currentLoginUser.setcustomer_sex(edtSex);
			BeanUser.currentLoginUser.setcustomer_mail(edtMail);
			BeanUser.currentLoginUser.setcustomer_city(edtCity);
			BeanUser.currentLoginUser.setcustomer_tel(edtTel);
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void sMsg(BeanUser user) throws BaseException{
		Frame FrmSMsg = null;
		FrmSMsg dlg=new FrmSMsg(FrmSMsg,"�鿴��Ϣ",true);
		dlg.setVisible(true);
	}

	@Override
	public List<BeanUser> loadAll() throws BaseException {
		List<BeanUser> result=new ArrayList<BeanUser>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT customer_id,customer_name,customer_sex,customer_pwd,customer_tel"
					+ ",customer_mail,customer_city,customer_register_date,vip,vip_deadline"
					+ " from customer_msg";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanUser p=new BeanUser();
				p.setUser_id(rs.getInt(1));
				p.setcustomer_name(rs.getString(2));
				p.setcustomer_sex(rs.getString(3));
				p.setPwd(rs.getString(4));
				p.setcustomer_tel(rs.getString(5));
				p.setcustomer_mail(rs.getString(6));
				p.setcustomer_city(rs.getString(7));
				p.setRegister_time(rs.getTimestamp(8));
				p.setVip(rs.getString(9));
				p.setvip_deadline(rs.getString(10));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public BeanManager reg2(String name, String pwd, String pwd2)
			throws BaseException {
		if(name==null || "".equals(name))throw new BusinessException("�û�������Ϊ��!");
		if(pwd==null || "".equals(pwd))throw new BusinessException("���벻��Ϊ��!");
		if(pwd2==null || "".equals(pwd2))throw new BusinessException("���벻��Ϊ��!");
		if(!pwd.equals(pwd2)) throw new BusinessException("��������������벻һ�£�");

		Connection conn=null;
		try {
			String sql="select m_name from manager_msg where m_name=?";//?ռλ��
			conn=DBUtil.getConnection();
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,name);
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){
				
				rs.close();
				pst.close();
				throw new BusinessException("�û��Ѵ���");
			}
			
			sql="select max(m_id) from customer_msg";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			int mid = 0;
			if(rs.next()){
				mid=rs.getInt(1);//��ȡcustomer_id
			}
			st.close();
			
			sql="INSERT INTO `take1`.`manager_msg` (`m_id`, `m_name`, `m_pwd`) VALUES (?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1, mid+1);
			pst.setString(2, name);
			pst.setString(3, pwd);
			pst.execute();
			BeanManager manager=new BeanManager();
			manager.setm_id(rs.getInt(1));
			manager.setm_name(rs.getString(2));
			manager.setPwd(rs.getString(3));
			rs.close();
			pst.close();
			return manager;
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void changePwd2(BeanManager manager, String oldPwd, String newPwd,
			String newPwd2) throws BaseException {
		if(oldPwd==null || "".equals(oldPwd))throw new BusinessException("ԭ���벻��Ϊ��!");
		if(newPwd==null || "".equals(newPwd))throw new BusinessException("�����벻��Ϊ��!");
		if(newPwd2==null || "".equals(newPwd2))throw new BusinessException("�����벻��Ϊ��!");
		if(!newPwd.equals(newPwd2)) throw new BusinessException("�������벻һ�£�");
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select m_pwd"
					+ " from manager_msg where m_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,manager.getm_name());
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){
				if(!rs.getString("m_pwd").equals(oldPwd)){
					throw new BusinessException("ԭ���벻��ȷ��");
				}
			
			
			else{

				sql="update manager_msg set m_pwd=? where m_name=?";
				pst=conn.prepareStatement(sql);
				pst.setString(1,newPwd);
				pst.setString(2, manager.getm_name());
				pst.execute();//�޸�
				manager.setPwd(newPwd);
				rs.close();
				pst.close();
				JOptionPane.showMessageDialog(null,"�޸ĳɹ�");
			}
			
			}
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void update(BeanUser curcustomer, String id, String name,
			String sex, String pwd, String tel, String mail, String city,
			String registertime, String vip, String deadline)
			throws BaseException {
		
		if(name==null || "".equals(name))throw new BusinessException("�û�������Ϊ��!");
		if(vip=="��"){
			if(deadline==null || "".equals(deadline))throw new BusinessException("��Ա��ֹʱ�䲻��Ϊ��!");
		}
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="update customer_msg"
					+ " set customer_name=?,customer_sex=?,customer_pwd=?,customer_tel=?,customer_mail=?,"
					+ "customer_city=?,vip=?,vip_deadline=?"
					+ "where customer_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		
			pst.setString(1,name);
			pst.setString(2,sex);
			pst.setString(3,pwd);
			pst.setString(4,tel);
			pst.setString(5,mail);
			pst.setString(6,city);
			pst.setString(7,vip);
			//�ַ���ת����          
			
//			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");//�·���MM
//	        Date date = simpleDateFormat.parse(deadline);
		    pst.setString(8,deadline);
			
//			Timestamp ts = new Timestamp(System.currentTimeMillis());            
//	        ts = Timestamp.valueOf(deadline);
			

			
			pst.setString(9,curcustomer.getcustomer_name());
			pst.execute();
			curcustomer.setcustomer_name(name);
			curcustomer.setcustomer_sex(sex);
			curcustomer.setcustomer_tel(tel);
			curcustomer.setcustomer_mail(mail);
			curcustomer.setcustomer_city(city);
			curcustomer.setVip(vip);          
			curcustomer.setvip_deadline(deadline);
			JOptionPane.showMessageDialog(null,  "�޸ĳɹ�����ˢ��");
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		} finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	        
		}

	@Override
	public void deleteUser(BeanUser beanUser) throws BaseException {
		int customer_id=beanUser.getUser_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
//			String sql="select count(*) from goods_order where customer_id="+customer_id;//�鿴�Ƿ����ɾ���������ڲ����򲻿���ɾ
//			java.sql.Statement st=conn.createStatement();
//			java.sql.ResultSet rs=st.executeQuery(sql);
//			if(rs.next()){
//				if(rs.getInt(1)>0){
//					rs.close();
//					st.close();
//					throw new BusinessException("��������ɾ����");
//				}
//			}
//			rs.close();
			conn.setAutoCommit(false);
			String sql="delete from address where customer_id="+customer_id;
			java.sql.Statement st=conn.createStatement();
			st.execute(sql);
			sql="delete from customer_getticket_process where customer_id="+customer_id;
			st.execute(sql);
			sql="delete from customer_msg where customer_id="+customer_id;
			st.execute(sql);
			sql="delete from have_ticket where customer_id="+customer_id;
			st.execute(sql);
			sql="delete from customer_msg where customer_id="+customer_id;
			st.execute(sql);
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
			conn.commit();
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}


	

}
