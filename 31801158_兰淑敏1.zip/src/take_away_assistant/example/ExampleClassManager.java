package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;









import javax.swing.JOptionPane;

import take_away_assistant.Itf.IClassManager;
import take_away_assistant.bean.BeanClass;
import take_away_assistant.bean.BeanGoods;
import take_away_assistant.bean.BeanShop;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;

public class ExampleClassManager implements IClassManager {

	@Override
	public List<BeanClass> loadClass(BeanShop shop) throws BaseException {
		
		List<BeanClass> result=new ArrayList<BeanClass>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select goods_class_name,goods_class_id,oneclass_good_count FROM good_class"
					+ " where goods_class_id in"
					+ "(SELECT DISTINCT goods_class_id from goods_msg where goods_id in "
					+ "(SELECT goods_id from relation_shopandgoods WHERE shop_id=?))";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, shop.getShop_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanClass p=new BeanClass();
				p.set_className(rs.getString(1));
				p.set_classID(rs.getInt(2));
				p.set_setOneclass_good_count(rs.getInt(3));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;

	}

	@Override
	public List<BeanClass> loadAllClass() throws BaseException {
		List<BeanClass> result=new ArrayList<BeanClass>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT * from good_class";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			
			while(rs.next()){
				BeanClass p=new BeanClass();
				p.set_classID(rs.getInt(1));
				p.set_className(rs.getString(2));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public void delete(BeanClass beanClass) throws BaseException {
		int class_id=beanClass.get_classID();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="select 1 from goods_msg where goods_class_id="+class_id;
			java.sql.Statement st=conn.createStatement();
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		//	pst.setInt(1, shop_id);
			//pst.setInt(2, goods_id);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0){
					rs.close();
					st.close();
					throw new BusinessException("����д�����Ʒ��������ɾ����");
				}
			}
			rs.close();
			
			
			sql="delete from good_class where goods_class_id="+class_id;
			st.execute(sql);
			
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
			conn.commit();
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void insert(String name) throws BaseException {
		
		if(name==null||"".equals(name)) throw new BusinessException("��������Ϊ��");
		

		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			int class_id=0;
			
			String sql="SELECT MAX(goods_class_id) from good_class";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) class_id=rs.getInt(1)+1;
			
	
			
			
			rs.close();
			st.close();
			sql="INSERT INTO `take1`.`good_class` (`goods_class_id`, `goods_class_name`, `oneclass_good_count`)"
					+ " VALUES (?, ?, 0)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst=conn.prepareStatement(sql);
			pst.setInt(1, class_id);
			pst.setString(2, name);
	
			pst.execute();
			pst.close();
			
			
		}catch(SQLException ex){
			ex.printStackTrace();
			throw new DbException(ex);
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	
	}
}