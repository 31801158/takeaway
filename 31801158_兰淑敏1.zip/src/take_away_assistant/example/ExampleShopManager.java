package take_away_assistant.example;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import take_away_assistant.Itf.IShopManager;
import take_away_assistant.bean.BeanShop;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmManager;

public class ExampleShopManager implements IShopManager {

	@Override
	public BeanShop addShop(String name) throws BaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BeanShop> loadAll() throws BaseException {
		List<BeanShop> result=new ArrayList<BeanShop>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select shop_id,shop_name,shop_star,consume_aver,sales_volume,all_comment_count from shop_msg order by shop_id";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanShop p=new BeanShop();
				p.setShop_id(rs.getInt(1));
				p.setShop_name(rs.getString(2));
				p.setShop_star(rs.getBigDecimal(3));
				p.setShop_consume_aver(rs.getInt(4));
				p.setShop_sales_volume(rs.getInt(5));
				p.setShop_all_comment_count(rs.getInt(6));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
		
	}

	@Override
	public void deleteShop(BeanShop shop) throws BaseException {
		int shop_id=shop.getShop_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT count(*) from goods_order where shop_id="+shop_id+" and order_condition='������' or '��ʱ'";
			java.sql.Statement st=conn.createStatement();
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0){
					rs.close();
					st.close();
					throw new BusinessException("����δ��ɶ�����������ɾ����");
				}
			}
			rs.close();
			
			sql="delete from goods_comment where shop_id="+shop_id;
			st.execute(sql);
			sql="delete from have_ticket where shop_id="+shop_id;
			st.execute(sql);
			sql="delete from customer_getticket_process where shop_id="+shop_id;
			st.execute(sql);
//			sql="delete from goods_order where shop_id="+shop_id;��������ɾ
//			st.execute(sql);
			sql="delete from relation_customer_and_haveticket where shop_id="+shop_id;
			st.execute(sql);
			sql="delete from relation_shop_and_fullredution where shop_id="+shop_id;
			st.execute(sql);
			sql="delete from relation_shop_and_haveticket where shop_id="+shop_id;
			st.execute(sql);
			
			sql="delete from relation_shopandticket where shop_id="+shop_id;
			st.execute(sql);
			sql="delete from order_detil where order_id in (select order_id from goods_order where shop_id="+shop_id+")";
			st.execute(sql);
			sql="delete from relation_shopandgoods where shop_id="+shop_id;
			st.execute(sql);
			sql="delete from shop_msg where shop_id="+shop_id;
			st.execute(sql);
			
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void update(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("����Ϊ��!");
		int shop_id=FrmManager.curShop.getShop_id();
		BigDecimal bd;
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql;

			java.sql.Statement st = null;
			if(FrmManager.shopcolumn==1){//��
				sql="update shop_msg set shop_name='"+text+"' WHERE shop_id="+shop_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.curShop.setShop_name(text);
				
			}
			else if(FrmManager.shopcolumn==2){//�Ǽ�
				sql="update shop_msg set shop_star="+text+" WHERE shop_id="+shop_id;
				st=conn.createStatement();
				st.execute(sql);
				bd=new BigDecimal(text);
				FrmManager.curShop.setShop_star(bd);
				}
			
			else if(FrmManager.shopcolumn==3){//�˾�����
				
				try{
					sql="update shop_msg set consume_aver="+text+" WHERE shop_id="+shop_id;
					st=conn.createStatement();
					st.execute(sql);
					int a = Integer.parseInt(text);
					FrmManager.curShop.setShop_consume_aver(a);
				} catch (NumberFormatException e) {
					throw new BusinessException("�����������֣�");
				    }
			}
			else if(FrmManager.shopcolumn==4){//������
				
			try{
				sql="update shop_msg set sales_volume="+text+" WHERE shop_id="+shop_id;
				st=conn.createStatement();
				st.execute(sql);
				int a = Integer.parseInt(text);
				FrmManager.curShop.setShop_sales_volume(a);
			} catch (NumberFormatException e) {
				throw new BusinessException("�������Ϊ������");
			    }
			}
			st.close();
			JOptionPane.showMessageDialog(null,  "�޸ĳɹ�����ˢ��");
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		} finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void insert(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("����Ϊ��!");
		int shop_id=0;
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT max(shop_id) from shop_msg";
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				shop_id=rs.getInt(1)+1;//��ȡshop_id
			}
			rs.close();
			st.close();
			
			sql="INSERT INTO `take1`.`shop_msg` (`shop_id`, `shop_name`, `shop_star`, `consume_aver`, `sales_volume`, `all_comment_count`) "
					+ "VALUES (?, ?, 3.0, 0, 0, 0)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, shop_id);
			pst.setString(2, text);
			
			pst.execute();
			JOptionPane.showMessageDialog(null,  "�����ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

}
