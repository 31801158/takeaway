package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import take_away_assistant.Itf.IGoodsManager;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanClass;
import take_away_assistant.bean.BeanGoods;
import take_away_assistant.bean.BeanShop;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmMain;
import take_away_assistant.ui.FrmManager;

public class ExampleGoodsManager implements IGoodsManager {

	@Override
	public List<BeanGoods> loadGoods(BeanClass aclass) throws BaseException {
		List<BeanGoods> result=new ArrayList<BeanGoods>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select DISTINCT goods_msg.goods_id,good_name,goods_class_id,price,d_price,stock,sales"
					+ " from goods_msg,relation_shopandgoods"
					+ " where goods_msg.goods_id=relation_shopandgoods.goods_id and shop_id=? and goods_msg.goods_id in"
					+ " (select t1.goods_id from goods_msg t1,relation_shopandgoods t2"
					+ " where t1.goods_id=t2.goods_id and shop_id=? and goods_class_id=?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			int shop_id;
			if(FrmMain.curShop==null)shop_id=FrmManager.curShop.getShop_id();
			else shop_id=FrmMain.curShop.getShop_id();
			pst.setInt(1, shop_id);
			pst.setInt(2, shop_id);
			pst.setInt(3, aclass.get_classID());
			
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanGoods p=new BeanGoods();
				p.setGoodsName(rs.getString(2));
				p.setGoodsID(rs.getInt(1));
				p.setGoodsClassId(rs.getInt(3));
				p.setPrice(rs.getFloat(4));
				p.setDPrice(rs.getFloat(5));
				p.setStock(rs.getInt(6));
				p.setSales(rs.getInt(7));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public void addcart(BeanGoods beanGoods) throws BaseException {
		int goods_id=beanGoods.getGoodsID();
		int class_id=beanGoods.getGoodsClassId();
		int shop_id=FrmMain.curShop.getShop_id();
		int customer_id=BeanUser.currentLoginUser.getUser_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT * from cart where shop_id="+shop_id+" and class_id="+class_id+" and goods_id="
			+goods_id+" and customer_id="+customer_id;
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				sql="update cart set goods_count=goods_count+1 where shop_id="+shop_id+" and class_id="+class_id+" and goods_id="
			+goods_id+" and customer_id="+customer_id;
				st.execute(sql);
			}
			else{
			sql="INSERT INTO `take1`.`cart` (`shop_id`, `class_id`, `goods_id`, `customer_id`,`goods_count`) "
					+ "VALUES (?, ?, ?, ?,1)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, shop_id);
			pst.setInt(2, class_id);
			pst.setInt(3, goods_id);
			pst.setInt(4, customer_id);
			
			pst.execute();
			}
			JOptionPane.showMessageDialog(null,  "�����ɹ�");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void delete(BeanShop beanShop, BeanGoods beanGoods)
			throws BaseException {//���̼���ɾ��  �����Ǵ���Ʒ����ɾ��
		int shop_id=beanShop.getShop_id();
		int goods_id=beanGoods.getGoodsID();
		int class_id=beanGoods.getGoodsClassId();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT 1 from goods_order where shop_id="+shop_id
					+ " and order_id in(SELECT order_id from order_detil where goods_id="+goods_id+")";
			
			java.sql.Statement st=conn.createStatement();
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		//	pst.setInt(1, shop_id);
			//pst.setInt(2, goods_id);
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0){
					rs.close();
					st.close();
					throw new BusinessException("����δ��ɶ�����������ɾ����");
				}
			}
			rs.close();
			
			
			sql="delete from relation_shopandgoods where shop_id="+shop_id+" and goods_id="+goods_id;
			
			st.execute(sql);
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}



	@Override
	public void add(BeanShop curShop, String text,String text1) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("����Ϊ��!");
		if(text1==null || "".equals(text1))throw new BusinessException("����Ϊ��!");
		int goods_id=Integer.parseInt(text);
		int stock=Integer.parseInt(text1);
		if(stock==0)throw new BusinessException("����Ϊ0!");
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			
			String sql="select 1 from relation_shopandgoods where goods_id="+goods_id+" and shop_id="+curShop.getShop_id();
			
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				JOptionPane.showMessageDialog(null,  "��Ʒ�Ѵ��ڣ�");
				return;
			}

			sql="select 1 from goods_msg where goods_id="+goods_id;
			rs=st.executeQuery(sql);
			if(!rs.next()){
				JOptionPane.showMessageDialog(null, "��Ʒ������", "����",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			sql="INSERT INTO `take1`.`relation_shopandgoods` (`goods_id`, `shop_id`, `stock`) "
					+ "VALUES (?, ?, ?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, goods_id);
			pst.setInt(2,curShop.getShop_id());
			pst.setInt(3,stock);

			pst.execute();
			rs.close();
			st.close();
			pst.close();
			JOptionPane.showMessageDialog(null,  "�����ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public List<String> loadRecomend() throws BaseException {
		List<String> result=new ArrayList<String>();
		
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			
			String sql="select count(*) from relation_shopandgoods ";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)<3){
					JOptionPane.showMessageDialog(null, "�̵�����Ʒ���٣����Ƽ��ˣ�");
					return null;
				}
			}else return null;
			sql="select goods_id,shop_id,sales from relation_shopandgoods ORDER BY sales desc limit 3";
			rs=st.executeQuery(sql);
			while(rs.next()){
				result.add(Integer.toString(rs.getInt(1)));
				result.add(Integer.toString(rs.getInt(2)));
				result.add(Integer.toString(rs.getInt(3)));
				
			}
			rs.close();
			st.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public List<BeanGoods> loadAllGoods() throws BaseException {
		List<BeanGoods> result=new ArrayList<BeanGoods>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT * from goods_msg";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			
			while(rs.next()){
				BeanGoods p=new BeanGoods();
				p.setGoodsID(rs.getInt(1));
				p.setGoodsClassId(rs.getInt(2));
				p.setGoodsName(rs.getString(3));
				p.setPrice(rs.getFloat(4));
				p.setDPrice(rs.getFloat(5));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public void delete1(BeanGoods beanGoods) throws BaseException {//����Ʒ����ɾ��
		int goods_id=beanGoods.getGoodsID();
		int class_id=beanGoods.getGoodsClassId();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="SELECT 1 from order_detil where goods_id="+goods_id;
			java.sql.Statement st=conn.createStatement();
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		//	pst.setInt(1, shop_id);
			//pst.setInt(2, goods_id);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0){
					rs.close();
					st.close();
					throw new BusinessException("�Ѵ��ڶ�����������ɾ����");
				}
			}
			rs.close();
			
			
			sql="delete from relation_shopandgoods where goods_id="+goods_id;
			st.execute(sql);
			sql="delete from goods_msg where goods_id="+goods_id;
			st.execute(sql);
			
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
			conn.commit();
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void insert(String name, String classid, String price, String dprice)
			throws BaseException {
		if(name==null||"".equals(name)) throw new BusinessException("��Ʒ������Ϊ��");
		if(classid==null||"".equals(classid)) throw new BusinessException("����Ų���Ϊ��");
		if(price==null||"".equals(price)) throw new BusinessException("�۸���Ϊ��");
		if(dprice==null||"".equals(dprice)) throw new BusinessException("�Żݼ۸���Ϊ��");

		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			int goods_id=0;
			
			String sql="select max(goods_id) from goods_msg";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) goods_id=rs.getInt(1)+1;
			
	
			sql="select goods_class_id from good_class where goods_class_id="+classid;
			rs=st.executeQuery(sql);
			if(!rs.next()){
				throw new BusinessException("����Ų�����");
			}
			
			rs.close();
			st.close();
			sql="INSERT INTO `take1`.`goods_msg` (`goods_id`, `goods_class_id`, `good_name`, `price`, `d_price`)"
					+ " VALUES (?, ?, ?, ?, ?);";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst=conn.prepareStatement(sql);
			pst.setInt(1, goods_id);
			pst.setInt(2, Integer.parseInt(classid));
			pst.setString(3, name);
			pst.setFloat(4, Float.parseFloat(price));
			pst.setFloat(5, Float.parseFloat(dprice));
			pst.execute();
			pst.close();
			
			
		}catch(SQLException ex){
			ex.printStackTrace();
			throw new DbException(ex);
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
		
	}

}
