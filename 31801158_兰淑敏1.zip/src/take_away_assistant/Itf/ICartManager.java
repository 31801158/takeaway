package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanCart;
import take_away_assistant.others.BaseException;

public interface ICartManager {
	public List<BeanCart> loadCart()throws BaseException;

	public void remove(BeanCart beanCart)throws BaseException;
}
