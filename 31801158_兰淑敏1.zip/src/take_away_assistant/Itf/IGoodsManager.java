package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanClass;
import take_away_assistant.bean.BeanGoods;
import take_away_assistant.bean.BeanShop;
import take_away_assistant.others.BaseException;


public interface IGoodsManager {
	public List<BeanGoods> loadGoods(BeanClass aclass)throws BaseException;//�ͻ�

	public void addcart(BeanGoods beanGoods)throws BaseException;

	public void delete(BeanShop beanShop, BeanGoods beanGoods)throws BaseException;

	//public void add(BeanShop beanShop)throws BaseException;

	public void add(BeanShop curShop, String text, String text1)throws BaseException;

	public List<String> loadRecomend()throws BaseException;

	public List<BeanGoods> loadAllGoods()throws BaseException;//����Ա

	public void delete1(BeanGoods beanGoods)throws BaseException;

	public void insert(String name, String classid, String price, String dprice)throws BaseException;
}
