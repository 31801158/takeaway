package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanTicket;
import take_away_assistant.others.BaseException;



public interface ITicketManager {
	public List<BeanTicket> loadTicket()throws BaseException;

	public List<BeanTicket> loadTicket1() throws BaseException;

	public void insert(String money, String require, String start, String end)throws BaseException;

	public void update(String text)throws BaseException;

	public void delete(BeanTicket beanTicket) throws BaseException;//����Աɾ��
	public void delete1(String tid) throws BaseException;//�ͻ��µ���ɾ��
	public int ifExist(String id) throws BaseException;

	public List<BeanTicket> loadTicketProcess() throws BaseException;

	public void addtoshop(String text)throws BaseException;

	public void deletefromshop(String text)throws BaseException;
}
