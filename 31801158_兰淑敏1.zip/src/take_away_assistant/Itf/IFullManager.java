package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanFull;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.others.BaseException;

public interface IFullManager {

	public List<BeanFull> loadFull()throws BaseException;

	public void insert(String full, String redution, String with)throws BaseException;

	public void update(String text) throws BaseException;

	public void delete(BeanFull beanFull)throws BaseException;

	public void deletefromshop(String text)throws BaseException;

	public void addtoshop(String text)throws BaseException;
}
