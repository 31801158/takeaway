package take_away_assistant.Itf;

import java.util.List;



import javax.swing.JTextField;

import take_away_assistant.bean.BeanOrders;
import take_away_assistant.others.BaseException;

public interface IOrdersManager {
	public List<BeanOrders> loadOrders()throws BaseException;
	public void showAllOrders()throws BaseException;
	public void deleteOrders(BeanOrders orders)throws BaseException;
	public int insert(int shop_id, int user_id, String ticket_id, String require_time,
			String address)throws BaseException;
	public void receiveOrders(BeanOrders beanOrders)throws BaseException;
}
