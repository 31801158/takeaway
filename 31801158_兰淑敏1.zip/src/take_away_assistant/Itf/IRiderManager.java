package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanRider;
import take_away_assistant.others.BaseException;

public interface IRiderManager {
	public List<BeanRider> loadAll()throws BaseException;

	public void deleteRider(BeanRider beanRider)throws BaseException;

	public void update(String text)throws BaseException;

	public void insert(String text)throws BaseException;
}
