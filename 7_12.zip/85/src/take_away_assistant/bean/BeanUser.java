package take_away_assistant.bean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;


public class BeanUser {
	public static BeanUser currentLoginUser=null;//ȫ�ֱ�����ǰ�û�
	public static int currentLoginUserType=0;//0�ͻ�  1����Ա
	public static final String[] tableTitles={"�ͻ����","�û���","�Ա�","����","��ϵ�绰","����","���ڵ�","ע��ʱ��","�Ƿ�Ϊ��Ա","��Ա��ֹʱ��"};
	private int user_id;
	private String customer_name;
	private String customer_sex;
	private String user_pwd;
	private String customer_tel;
	private String customer_mail;
	private String customer_city;
	private Timestamp customer_register_date;//��ʱ�䲻������
	private String vip;
	private String vip_deadline;
	
	public String getCell(int col) throws DbException, BusinessException{
			if(col==0) return Integer.toString(this.user_id);
			else if(col==1) return this.customer_name;
			else if(col==2) return this.customer_sex;
			else if(col==3) return this.user_pwd;
			else if(col==4) return this.customer_tel;
			else if(col==5) return this.customer_mail;
			else if(col==6) return this.customer_city;
			else if(col==7){
				String dateStr = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.customer_register_date);
				return dateStr;
			} 
			else if(col==8) return this.vip;
			else if(col==9) return this.vip_deadline;
//			{
//				String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(this.vip_deadline);
//				if("2000-08-27".equals(dateStr)){//���ǻ�Ա���ؿ��ַ���
//					return "";}
//				else{//ʱ���ת��������
//				return dateStr;
//				}
//			}
			else return "";
		
		
	}
	
	public void setUser_id(int userid) {
		this.user_id=userid;
	}
	public int getUser_id(){
		return user_id;
	}
	
	public void setRegister_time(Timestamp timestamps) {
		this.customer_register_date=timestamps; 
	}
	public Timestamp getRegister_time(){
		return customer_register_date;
	}

	public void setPwd(String newPwd) {
		this.user_pwd=newPwd;
	}
	public String getPwd(){
		return user_pwd;
	}
	
	public void setcustomer_name(String newPwd) {
		this.customer_name=newPwd;
	}
	public String getcustomer_name(){
		return customer_name;
	}
	public void setcustomer_sex(String customer_sex) {
		this.customer_sex=customer_sex;
	}
	public String getcustomer_sex(){
		return customer_sex;
	}
	
	
	public void setcustomer_tel(String customer_tel) {
		this.customer_tel=customer_tel;
	}
	public String getcustomer_tel(){
		return customer_tel;
	}
	
	public void setcustomer_mail(String customer_mail) {
		this.customer_mail=customer_mail;
	}
	public String getcustomer_mail(){
		return customer_mail;
	}
	public void setcustomer_city(String customer_city) {
		this.customer_city=customer_city;
	}
	public String getcustomer_city(){
		return customer_city;
	}
	


	
	public void setVip(String vip) {
		this.vip=vip;
	}
	public String getVip(){
		return vip;
	}

	
	public void setvip_deadline(String vip) {
		this.vip_deadline=vip;
	}
	public String getvip_deadline(){
		return vip_deadline;
	}
}
