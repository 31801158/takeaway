package take_away_assistant.bean;

import java.text.SimpleDateFormat;
import java.util.Date;

import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DbException;

public class BeanRider {
	public static final String[] tblRiderTitles={"���ֱ��","��������","��ְ����","��������","�������˽��","���½ӵ�����"};
	private int rider_id;
	private String rider_name;
	private Date entry_date;
	private String rider_rank;
	private float rider_all_money;
	private int rider_order_count;
	
	public String getCell(int col) throws DbException, BusinessException{
			if(col==0) return Integer.toString(this.rider_id);
			else if(col==1) return this.rider_name;
			else if(col==2){
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			    return dateFormat.format( this.entry_date );
			}
			else if(col==3) return this.rider_rank;
			else if(col==4) return Float.toString(this.rider_all_money);
			else if(col==5) return Integer.toString(this.rider_order_count);
			else return "";
	}
	
	public void setrider_id(int shopid){
		this.rider_id=shopid;
	}
	public int getrider_id(){
		return rider_id;
	}
	public void setrider_name(String shopname){
		this.rider_name=shopname;
	}
	public String getrider_name(){
		return rider_name;
	}
	
	public void setentry_date(Date shopname){
		this.entry_date=shopname;
	}
	public Date getentry_date(){
		return entry_date;
	}

	
	public void setrider_rank(String shopname){
		this.rider_rank=shopname;
	}
	public String getrider_rank(){
		return rider_rank;
	}
	
	public void setrider_all_money(float shopname){
		this.rider_all_money=shopname;
	}
	public float getrider_all_money(){
		return rider_all_money;
	}
	
	
	public void setrider_order_count(int shopid){
		this.rider_order_count=shopid;
	}
	public int getrider_order_count(){
		return rider_order_count;
	}

}
