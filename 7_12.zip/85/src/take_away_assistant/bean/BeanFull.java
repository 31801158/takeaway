package take_away_assistant.bean;


public class BeanFull {

	public static final String[] tableTitles={"�������","�������","�Żݽ��","�Ƿ�����Ż�ȯ����","�̼ұ��"};
	private int full_redution_id;
	private float full_momey;
	private float redution_money;
	private int use_with_ticket;
	private int shop_id;
	
	public String getCell(int col){
		if(col==0) return Integer.toString(this.full_redution_id);
		else if(col==1) return Float.toString(this.full_momey);
		else if(col==2) return Float.toString(this.redution_money);
		else if(col==3) return Integer.toString(this.use_with_ticket);
		else if(col==4) return Integer.toString(this.shop_id);
		else return "";
	}
	
	public void setfull_redution_id(int stepid){
		this.full_redution_id=stepid;
	}
	public int getfull_redution_id(){
		return full_redution_id;
	}
	
	public void setfull_momey(float stepid){
		this.full_momey=stepid;
	}
	public float getfull_momey(){
		return full_momey;
	}
	public void setredution_money(float stepid){
		this.redution_money=stepid;
	}
	public float getredution_money(){
		return redution_money;
	}
	
	public void setuse_with_ticket(int stepid){
		this.use_with_ticket=stepid;
	}
	public int getuse_with_ticket(){
		return use_with_ticket;
	}
	
	public void setshop_id(int stepid){
		this.shop_id=stepid;
	}
	public int getshop_id(){
		return shop_id;
	}

	
	
	
	
	
}
