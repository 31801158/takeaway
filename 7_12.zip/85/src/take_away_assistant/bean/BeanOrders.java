package take_away_assistant.bean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class BeanOrders {
	public static final String[] tblorderTitle={"�������","�̵���","���ֱ��","ԭʼ���","������","�������","ʹ���Ż�ȯ���","�µ�ʱ��","Ҫ���ʹ�ʱ��","���͵�ַ���","����״̬","����״̬"};
	private int order_id;
	private int shop_id;
	private int customer_id;
	private int rider_id;
	private float original_price;
	private float final_price;
	private int full_redution_id;
	private int ticket_id;
	private Timestamp order_time;
	private Timestamp require_arrive_time;
	private int address_id;
	private String order_condition;
	private String ifcomment;
	public String getCell(int col){
		if(col==0) return Integer.toString(this.order_id);
		else if(col==1) return Integer.toString(this.shop_id);
		else if(col==2) return Integer.toString(this.rider_id);
		else if(col==3) return Float.toString(this.original_price);
		else if(col==4) return Float.toString(this.final_price);
		else if(col==5) return Integer.toString(this.full_redution_id);
		else if(col==6) return Integer.toString(this.ticket_id);
		else if(col==7){
			String dateStr = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.order_time);
			return dateStr;
		}
		else if(col==8){
			String dateStr = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.require_arrive_time);
			return dateStr;
		}
		else if(col==9) return Integer.toString(this.address_id);
		else if(col==10) return this.order_condition;
		else if(col==11) return this.ifcomment;
		else return "";
	}
	
	public void setOrder_id(int stepid){
		this.order_id=stepid;
	}
	public int getOrder_id(){
		return order_id;
	}
	
	public void setShop_id(int stepid){
		this.shop_id=stepid;
	}
	public int getShop_id(){
		return shop_id;
	}
	
	public void setCustomer_id(int stepid){
		this.customer_id=stepid;
	}
	public int getCustomer_id(){
		return customer_id;
	}
	
	public void setRider_id(int stepid){
		this.rider_id=stepid;
	}
	public int getRider_id(){
		return rider_id;
	}
	
	public void setOriginal_price(float stepid){
		this.original_price=stepid;
	}
	public float getOriginal_price(){
		return original_price;
	}
	
	public void setFinal_price(float stepid){
		this.final_price=stepid;
	}
	public float getFinal_price(){
		return final_price;
	}
	
	public void setFull_redution_id(int stepid){
		this.full_redution_id=stepid;
	}
	public int getFull_redution_id(){
		return full_redution_id;
	}
	
	public void setTicket_id(int stepid){
		this.ticket_id=stepid;
	}
	public int getTicket_id(){
		return ticket_id;
	}
	
	public void setOrder_time(Timestamp ordertime){
		this.order_time= ordertime;
	}
	public Timestamp getOrder_time(){
		return order_time;
	}
	
	public void setrequire_arrive_time(Timestamp stepid){
		this.require_arrive_time=stepid;
	}
	public Timestamp getrequire_arrive_time(){
		return require_arrive_time;
	}

	
	public void setAddress_id(int stepid){
		this.address_id=stepid;
	}
	public int getAddress_id(){
		return address_id;
	}
	
	public void setOrder_condition(String stepid){
		this.order_condition=stepid;
	}
	public String getOrder_condition(){
		return order_condition;
	}
	
	public void setIfcomment(String stepid){
		this.ifcomment=stepid;
	}
	public String getIfcomment(){
		return ifcomment;
	}

	
}
