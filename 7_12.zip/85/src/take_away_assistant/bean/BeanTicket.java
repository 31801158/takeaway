package take_away_assistant.bean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class BeanTicket {
	public static final String[] tableTitles={"�Ż�ȯ���","�����̼ұ��","�Żݽ��","����","��ֹ����"};
	public static final String[] tableTitles1={"�Ż�ȯ���","�Żݽ��","����Ҫ����","��ʼ����","��������","�̼ұ��"};
	private int customer_id;
	private int shop_id;
	private int ticket_id;
	private int ticket_count;
	private float ticket_money;
	private Timestamp end_date;
	
	private int get_ticket_require;
	private Timestamp start_date;
	
	public String getCell(int col){
		if(col==0) return Integer.toString(this.ticket_id);
		else if(col==1) return Integer.toString(this.shop_id);
		else if(col==2) return Float.toString(this.ticket_money);
		else if(col==3) return Integer.toString(this.ticket_count);
		else if(col==4){
			String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(this.end_date);
			return dateStr;
		}
		else return "";
	}
	
	public String getCell1(int col){
		if(col==0) return Integer.toString(this.ticket_id);
		else if(col==1) return Float.toString(this.ticket_money);
		if(col==2) return Integer.toString(this.get_ticket_require);
		else if(col==3){
			String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(this.end_date);
			return dateStr;
		}
		else if(col==4){
			String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(this.end_date);
			return dateStr;
		}
		if(col==5) return Integer.toString(this.shop_id);
		else return "";
	}
	
	public void setcustomer_id(int stepid){
		this.customer_id=stepid;
	}
	public int getcustomer_id(){
		return customer_id;
	}
	public void setshop_id(int stepid){
		this.shop_id=stepid;
	}
	public int getshop_id(){
		return shop_id;
	}

	public void setticket_id(int stepid){
		this.ticket_id=stepid;
	}
	public int getticket_id(){
		return ticket_id;
	}
	public void setticket_count(int stepid){
		this.ticket_count=stepid;
	}
	public int getticket_count(){
		return ticket_count;
	}


	public void setticket_money(float stepid){
		this.ticket_money=stepid;
	}
	public float getticket_money(){
		return ticket_money;
	}
	public void setend_date(Timestamp ordertime){
		this.end_date= ordertime;
	}
	public Timestamp getend_date(){
		return end_date;
	}
	
	
	public void setGet_ticket_require(int stepid){
		this.get_ticket_require=stepid;
	}
	public int getGet_ticket_require(){
		return get_ticket_require;
	}

	public void setstart_date(Timestamp ordertime){
		this.start_date= ordertime;
	}
	public Timestamp getstart_date(){
		return start_date;
	}

}
