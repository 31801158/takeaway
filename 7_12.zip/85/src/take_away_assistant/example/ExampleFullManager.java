package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import take_away_assistant.Itf.IFullManager;
import take_away_assistant.bean.BeanFull;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;

public class ExampleFullManager implements IFullManager{

	@Override
	public List<BeanFull> loadFull() throws BaseException {
		List<BeanFull> result=new ArrayList<BeanFull>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select full_redution.full_redution_id,full_momey,full_momey,use_with_ticket,shop_id"
					+ " from full_redution,relation_shop_and_fullredution"
					+ " where full_redution.full_redution_id=relation_shop_and_fullredution.full_redution_id"
					+ " order by full_redution.full_redution_id";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanFull p =new BeanFull();
				p.setfull_redution_id(rs.getInt(1));
				p.setfull_momey(rs.getFloat(2));
				p.setredution_money(rs.getInt(3));
				p.setuse_with_ticket(rs.getInt(4));
				p.setshop_id(rs.getInt(5));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;

	}

}
