package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import take_away_assistant.Itf.IRiderManager;
import take_away_assistant.bean.BeanRider;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmManager;

public class ExampleRiderManager implements IRiderManager{

	@Override
	public List<BeanRider> loadAll() throws BaseException {
		List<BeanRider> result=new ArrayList<BeanRider>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT rider_id,rider_name,entry_date,rider_rank,rider_all_money,rider_order_count"
					+ " from rider_msg order by rider_id";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanRider p=new BeanRider();
				p.setrider_id(rs.getInt(1));
				p.setrider_name(rs.getString(2));
				p.setentry_date(rs.getDate(3));
				p.setrider_rank(rs.getString(4));
				p.setrider_all_money(rs.getFloat(5));
				p.setrider_order_count(rs.getInt(6));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public void deleteRider(BeanRider beanRider) throws BaseException {
		int rider_id=beanRider.getrider_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT count(*) from goods_order where rider_id="+rider_id+" and order_condition='������'or '��ʱ'";
			java.sql.Statement st=conn.createStatement();
			//java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0){
					rs.close();
					st.close();
					throw new BusinessException("����δ��ɶ�����������ɾ����");
				}
			}
			rs.close();
			
			
			sql="delete from rider_msg where rider_id="+rider_id;
			st.execute(sql);
			JOptionPane.showMessageDialog(null,  "ɾ���ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void update(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("����Ϊ��!");
		int rider_id=FrmManager.currider.getrider_id();
		Date entry_date=FrmManager.currider.getentry_date();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql;
			java.sql.PreparedStatement pst;
			java.sql.ResultSet rs;
			java.sql.Statement st;
			if(FrmManager.rightcolumn==1){//��
				sql="update rider_msg set rider_name="+text+" WHERE rider_id="+rider_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.currider.setrider_name(text);
				
			}
			else if(FrmManager.rightcolumn==2){//��ְ����
				
				
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
				Date date;
				try {
					date = simpleDateFormat.parse(text);
					sql="update rider_msg set entry_date='"+text+"' WHERE rider_id="+rider_id;
					st=conn.createStatement();
					st.execute(sql);
					FrmManager.currider.setentry_date(date);
					String cdate = simpleDateFormat.format( new Date() );
			        
			        int y1=Integer.parseInt(cdate.substring(0, 4));
			        int m1=Integer.parseInt(cdate.substring(5, 7));
			        int d1=Integer.parseInt(cdate.substring(8, 10));
			        String edate= simpleDateFormat.format(FrmManager.currider.getentry_date());
			        int y2=Integer.parseInt(edate.substring(0, 4));
			        int m2=Integer.parseInt(edate.substring(5, 7));
			        int d2=Integer.parseInt(edate.substring(8, 10));
					float f=(y1-y2)*12+(m1-m2)+(d1-d2)/30;
			        if(f>=3){
			        	sql="update rider_msg set rider_rank='"+"��ʽԱ��"+"' WHERE rider_id="+rider_id;
						st.execute(sql);
						FrmManager.currider.setrider_rank("��ʽԱ��");
			        }else{
			        	sql="update rider_msg set rider_rank='"+"����"+"' WHERE rider_id="+rider_id;
						st.execute(sql);
						FrmManager.currider.setrider_rank("����");
			        }
			        st.close();
				} catch (ParseException e) {
					throw new BusinessException("�밴xxxx-xx-xx��ʽ���룡����1997-08-05");
				}
				
				
				
				}
			else if(FrmManager.rightcolumn==3){//����
				sql="update rider_msg set rider_rank="+text+" WHERE rider_id="+rider_id;
				st=conn.createStatement();
				st.execute(sql);
				FrmManager.currider.setrider_rank(text);
			}
			else if(FrmManager.rightcolumn==4){//�ܽ��
				
				try{
					sql="update rider_msg set rider_all_money="+text+" WHERE rider_id="+rider_id;
					st=conn.createStatement();
					st.execute(sql);
					float a = Float.parseFloat(text);
					FrmManager.currider.setrider_all_money(a);
				} catch (NumberFormatException e) {
					throw new BusinessException("�����������֣�");
				    }
			}
			else if(FrmManager.rightcolumn==5){//�ܵ���
				
			try{
				sql="update rider_msg set rider_order_count="+text+" WHERE rider_id="+rider_id;
				st=conn.createStatement();
				st.execute(sql);
				int a = Integer.parseInt(text);
				FrmManager.currider.setrider_order_count(a);
			} catch (NumberFormatException e) {
				throw new BusinessException("�������Ϊ������");
			    }
			}
			
			JOptionPane.showMessageDialog(null,  "�޸ĳɹ�����ˢ��");
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		} finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void insert(String text) throws BaseException {
		if(text==null || "".equals(text))throw new BusinessException("����Ϊ��!");
		int rider_id=0;
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT max(rider_id) from rider_msg";
			java.sql.Statement st=conn.createStatement();
			
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				rider_id=rs.getInt(1)+1;//��ȡrider_id
			}
			rs.close();
			st.close();
			
			sql="INSERT INTO `take1`.`rider_msg` (`rider_id`, `rider_name`, `entry_date`, `rider_rank`, `rider_all_money`, `rider_order_count`) "
					+ "VALUES (?, ?, ?, '����', 0.0, 0)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, rider_id);
			pst.setString(2, text);
			Date t= new java.sql.Date(System.currentTimeMillis());
			pst.setDate(3, (java.sql.Date) t);

			pst.execute();
			JOptionPane.showMessageDialog(null,  "�����ɹ�����ˢ��");
		}catch(SQLException ex){
			ex.printStackTrace();
			try{
				conn.rollback();
			}catch(SQLException e){
				e.printStackTrace();
			}
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
}
