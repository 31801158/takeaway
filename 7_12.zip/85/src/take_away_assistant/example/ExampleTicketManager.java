package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import take_away_assistant.Itf.ITicketManager;
import take_away_assistant.bean.BeanClass;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;

public class ExampleTicketManager implements ITicketManager{//�û��鿴

	@Override
	public List<BeanTicket> loadTicket() throws BaseException {
		List<BeanTicket> result=new ArrayList<BeanTicket>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select shop_id,ticket_id,ticket_count,ticket_money,ticket_deadline "
					+ "from have_ticket where customer_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, BeanUser.currentLoginUser.getUser_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanTicket p =new BeanTicket();
				p.setcustomer_id(BeanUser.currentLoginUser.getUser_id());
				p.setshop_id(rs.getInt(1));
				p.setticket_id(rs.getInt(2));
				p.setticket_count(rs.getInt(3));
				p.setticket_money(rs.getFloat(4));
				p.setend_date(rs.getTimestamp(5));
				result.add(p);

			}
			rs.close();
			pst.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	@Override
	public List<BeanTicket> loadTicket1() throws BaseException {//����Ա�鿴
		List<BeanTicket> result=new ArrayList<BeanTicket>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="select ticket.ticket_id,ticket_money,get_ticket_require,"
					+ "ticket_start_date,ticket_end_date,shop_msg.shop_id"
					+ " from shop_msg,ticket,relation_shopandticket"
					+ " WHERE shop_msg.shop_id=relation_shopandticket.shop_id"
					+ " and relation_shopandticket.ticket_id=ticket.ticket_id order by ticket_id";
//			String sql="select ticket_id,ticket_money,get_ticket_require,ticket_start_date,ticket_end_date "
//					+ "from ticket order by ticket_id";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanTicket p =new BeanTicket();
				
				p.setticket_id(rs.getInt(1));
				p.setticket_money(rs.getFloat(2));
				p.setGet_ticket_require(rs.getInt(3));
				p.setstart_date(rs.getTimestamp(4));
				p.setend_date(rs.getTimestamp(5));
				p.setshop_id(rs.getInt(6));
				result.add(p);
			}
			sql="select ticket_id,ticket_money,get_ticket_require,ticket_start_date,ticket_end_date"
					+ " from ticket"
					+ " where ticket_id not in("
					+ "select DISTINCT ticket.ticket_id"
					+ " from shop_msg,ticket,relation_shopandticket"
					+ " WHERE shop_msg.shop_id=relation_shopandticket.shop_id"
					+ " and relation_shopandticket.ticket_id=ticket.ticket_id order by ticket_id)"
					+ " order by ticket_id";
			st=conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				BeanTicket p =new BeanTicket();
				
				p.setticket_id(rs.getInt(1));
				p.setticket_money(rs.getFloat(2));
				p.setGet_ticket_require(rs.getInt(3));
				p.setstart_date(rs.getTimestamp(4));
				p.setend_date(rs.getTimestamp(5));
				p.setshop_id(0);
				result.add(p);
;
			}
			rs.close();
			st.close();
			conn.close();
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	
}
