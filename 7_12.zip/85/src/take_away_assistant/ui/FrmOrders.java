package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;







import take_away_assistant.util;
import take_away_assistant.bean.BeanOrders;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;

public class FrmOrders extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JMenuBar menubar=new JMenuBar(); 
	private JMenuItem  menuItem_show=new JMenuItem("��ʾ���ж���");
    private JMenuItem  menuItem_delete=new JMenuItem("ɾ������");
    private JMenuItem  menuItem_comment=new JMenuItem("ȥ���� > ");
    private JMenuItem  menuItem_return=new JMenuItem("����������");
	private Object tblOrderTitle[]=BeanOrders.tblorderTitle;//��ͷ
	private Object tblOrderData[][];//���̼ң�������Ϣ
	DefaultTableModel tabOrderModel=new DefaultTableModel();//DefaultTableModel��ָĬ�ϵı�����ģ�� ������������ JTBALE ��JTABLE��GETTABLEMODEL���õ�һ��������ģ�������� JTBALE
	private JTable dataTableOrder=new JTable(tabOrderModel);//TableModel��JTable��ģ���൱��������һ��洢���ݶ���TableModelȥ�洢.�����,�ŵ�JTable��ȥ
	

	
	private BeanOrders curOrder=null;
	public static List<BeanOrders> orders=null;//���ж���  һ���б�
//	List<BeanClass> shopClass=null;
	
	private void reloadOrderTable() throws DbException, BusinessException{
		try {
			orders=util.ordersManager.loadOrders();//�г����ж��� ��һ���б�
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		//��������
		tblOrderData =  new Object[orders.size()][BeanOrders.tblorderTitle.length];
		for(int i=0;i<orders.size();i++){//��������  ����ÿһ������
			for(int j=0;j<BeanOrders.tblorderTitle.length;j++)
			 tblOrderData[i][j]=orders.get(i).getCell(j);
		}
		//����ģ��
		tabOrderModel.setDataVector(tblOrderData,tblOrderTitle);//�������ݺͱ�ͷ
		this.dataTableOrder.validate();
		this.dataTableOrder.repaint();
	}

	public FrmOrders() {
		//��ʼ���
		this.setExtendedState(Frame.MAXIMIZED_BOTH);//public int getExtendedState()��ȡ�˴����״̬����״̬��ʾΪ��λ���롣 
		this.setTitle("�ҵĶ���");
		
		//�˵�
		this.menubar.add(menuItem_show);this.menuItem_show.addActionListener(this);
		this.menubar.add(menuItem_delete);this.menuItem_delete.addActionListener(this);
		this.menubar.add(menuItem_comment);this.menuItem_comment.addActionListener(this);
		this.menubar.add(menuItem_return);this.menuItem_return.addActionListener(this);
		this.setJMenuBar(menubar);
		
		this.getContentPane().add(new JScrollPane(this.dataTableOrder), BorderLayout.CENTER);
		
		try {
			this.reloadOrderTable();
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BusinessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.menuItem_show){
			try {
				reloadOrderTable();
				this.setVisible(false);
				this.setVisible(true);
			} catch (DbException e1) {
				e1.printStackTrace();
			} catch (BusinessException e1) {
				e1.printStackTrace();
			}
			
		}
		else if(e.getSource()==this.menuItem_comment){
		
			
			int i=FrmOrders.this.dataTableOrder.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ��Ҫ���۵Ķ���", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(FrmOrders.orders.get(i).getIfcomment()=="������"||"������".equals(FrmOrders.orders.get(i).getIfcomment())){
				JOptionPane.showMessageDialog(null, "�Ѿ����۹���Ŷ��");
				return;
			}
			FrmComment dlg=new FrmComment(this,"���۶���",true);
			dlg.setVisible(true);
			//if(!(FrmComment.comment.get(0)==null||"".equals(FrmComment.comment.get(1)))){//������д��
			if(FrmComment.comment.size()!=0){	//���۶Ի����� ����� ��ȷ����
				String goods_name=null;
				int goods_id=0;
				int shop_id = 0;
				int rider_id=0;
				int customer_id=0;
				Date entry_date = null;
				float rider_all_money;
				float money=2;//��ǰ��������������
				float rider_order_count = 0;
				Connection conn=null;
				
				try {
					conn=DBUtil.getConnection();
					conn.setAutoCommit(false);
					String sql="select good_name,goods_id from goods_msg where goods_id=("
							+ "select goods_id from order_detil "
							+ "where order_id=?"
							+ ")";
					
					java.sql.PreparedStatement pst=conn.prepareStatement(sql);
					pst.setInt(1, FrmOrders.orders.get(i).getOrder_id());
					java.sql.ResultSet rs=pst.executeQuery();
					if(rs.next()){
						goods_name=rs.getString(1);
						goods_id=rs.getInt(2);

					}
					
					sql="select shop_id,customer_id,rider_id from goods_order"
							+ " where order_id=?";
					pst=conn.prepareStatement(sql);
					pst.setInt(1, FrmOrders.orders.get(i).getOrder_id());
					rs=pst.executeQuery();
					if(rs.next()){
						shop_id=rs.getInt(1);
						customer_id=rs.getInt(2);
						rider_id=rs.getInt(3);
					}
					
					//���Ķ�������״̬
					FrmOrders.orders.get(i).setIfcomment("������");
					sql="update goods_order set ifcomment='������' where order_id="+FrmOrders.orders.get(i).getOrder_id();
					java.sql.Statement st=conn.createStatement();
					st.execute(sql);
					
					if(FrmComment.comment.get(0)==null||"".equals(FrmComment.comment.get(1))){//û����д��Ʒ�������� Ĭ�Ϻ���
						sql="insert into goods_comment(goods_id,shop_id,customer_id,comment_date,star)"
								+ "VALUES(?,?,?,?,?)";//?ռλ��
						pst=conn.prepareStatement(sql);
						pst.setInt(1, goods_id);
						pst.setInt(2, shop_id);
						pst.setInt(3, customer_id);
						Timestamp time = Timestamp.valueOf(FrmComment.comment.get(3));
						pst.setTimestamp(4, time);
						pst.setString(5, FrmComment.comment.get(1));
						pst.execute();
					}
					else{
					sql="insert into goods_comment(goods_id,shop_id,customer_id,comment_content,comment_date,star)"
							+ "VALUES(?,?,?,?,?,?)";//?ռλ��
					
					pst=conn.prepareStatement(sql);
					pst.setInt(1, goods_id);
					pst.setInt(2, shop_id);
					pst.setInt(3, customer_id);
					pst.setString(4, FrmComment.comment.get(0));
					Timestamp time = Timestamp.valueOf(FrmComment.comment.get(3));
					pst.setTimestamp(5, time);
					pst.setString(6, FrmComment.comment.get(1));
					pst.execute();
					}
					//�����̵��Ǽ�
					sql="update shop_msg"
							+ " set shop_star=(shop_star*all_comment_count+"+FrmComment.comment.get(1)+")/(all_comment_count+1),all_comment_count=all_comment_count+1"
							+ " WHERE shop_id=?";
					pst=conn.prepareStatement(sql);
					pst.setInt(1, shop_id);
					pst.execute();
					//����������Ϣ
					sql="select entry_date,rider_all_money,rider_order_count"
							+ " from rider_msg where rider_id="+rider_id; 
					st=conn.createStatement();
					rs=st.executeQuery(sql);
					if(rs.next()){
						entry_date=rs.getDate(1);

						rider_all_money=rs.getFloat(2);
						rider_order_count=rs.getInt(3);
					}
					if(rider_order_count<100) money=2;
					else if(rider_order_count<300) money=3;
					else if(rider_order_count<450) money=5;
					else if(rider_order_count<550) money=6;
					else if(rider_order_count<650) money=7;
					else money=8;
					if(rider_order_count>=500) money+=0.5;;
					if(FrmComment.comment.get(2)=="����"||"����".equals(FrmComment.comment.get(2))) money+=0.5;
					sql="update rider_msg"
							+ " set rider_order_count=rider_order_count+1,rider_all_money=rider_all_money+"+money
							+ " WHERE rider_id=?";
					
					pst=conn.prepareStatement(sql);
					pst.setInt(1, rider_id);
					pst.execute();
					
					if(FrmComment.comment.get(2)=="����"||"����".equals(FrmComment.comment.get(2))){
						sql="update rider_msg"
								+ " set rider_all_money=rider_all_money-20"
								+ " WHERE rider_id=?";
					}
					pst=conn.prepareStatement(sql);
					pst.setInt(1, rider_id);
					pst.execute();
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			        String cdate =   dateFormat.format( new Date() );
			        
			        int y1=Integer.parseInt(cdate.substring(0, 4));
			        int m1=Integer.parseInt(cdate.substring(5, 7));
			        int d1=Integer.parseInt(cdate.substring(8, 10));
			        String edate= dateFormat.format(entry_date);
			        int y2=Integer.parseInt(edate.substring(0, 4));
			        int m2=Integer.parseInt(edate.substring(5, 7));
			        int d2=Integer.parseInt(edate.substring(8, 10));
			        float f=(y1-y2)*12+(m1-m2)+(d1-d2)/30;
	
			        if(f>=3) money+=0.5;
					rs.close();
					pst.close();
					
					conn.commit();
					FrmOrders.orders.get(i).setIfcomment("������");
					try {
						reloadOrderTable();
					} catch (DbException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (BusinessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} 
				catch(SQLException ex){
					ex.printStackTrace();
					try {
						throw new DbException(ex);
					} catch (DbException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}finally{
					if(conn!=null){
						try{
							conn.close();
						}catch(SQLException ex){
							ex.printStackTrace();
						}
					}
				}
			}
			FrmComment.comment.clear(); 
			
		}
		else if(e.getSource()==this.menuItem_delete){
			int i=FrmOrders.this.dataTableOrder.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ��Ҫɾ���Ķ���", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			try {
				util.ordersManager.deleteOrders(this.orders.get(i));
				reloadOrderTable();
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		else if(e.getSource()==this.menuItem_return){
			this.setVisible(false);
			
		}
	}

}
