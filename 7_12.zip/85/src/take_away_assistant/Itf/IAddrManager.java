package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanAddr;
import take_away_assistant.others.BaseException;



public interface IAddrManager {
	public List<BeanAddr> loadAddress()throws BaseException;

	public void delete(BeanAddr addr)throws BaseException;
	public BeanAddr add(String province,String town,String block,String speci,String name,String tel)throws BaseException;
	public void update(BeanAddr addr,String province,String town,String block,String speci,String name,String tel)throws BaseException;
}
