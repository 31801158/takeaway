package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanManager;
import take_away_assistant.bean.BeanShop;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;


public interface IUserManager {
	public BeanUser reg(String name,String pwd,String pwd2) throws BaseException;
	public BeanManager reg2(String name, String pwd,String pwd2) throws BaseException;
	public BeanUser login(String name,String pwd)throws BaseException;
	public BeanManager login2(String name,String pwd)throws BaseException;
	public void changePwd(BeanUser user, String oldPwd,String newPwd, String newPwd2)throws BaseException;
	public void comMsg(BeanUser user,String edtName,String edtSex,String edtCity,
			String edtMail,String edtTel)throws BaseException;
	public void sMsg(BeanUser user)throws BaseException;;
	public List<BeanUser> loadAll()throws BaseException;
	public void changePwd2(BeanManager manager, String oldPwd,String newPwd, String newPwd2) throws BaseException;
	public void update(BeanUser curcustomer, String id, String name,
			String sex, String pwd, String tel, String mail, String city,
			String registertime, String vip, String deadline) throws BaseException;
	public void deleteUser(BeanUser beanUser) throws BaseException;
	
}
