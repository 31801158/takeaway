package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanTicket;
import take_away_assistant.others.BaseException;



public interface ITicketManager {
	public List<BeanTicket> loadTicket()throws BaseException;

	public List<BeanTicket> loadTicket1() throws BaseException;
}
