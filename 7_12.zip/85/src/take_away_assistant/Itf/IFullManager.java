package take_away_assistant.Itf;

import java.util.List;

import take_away_assistant.bean.BeanFull;
import take_away_assistant.bean.BeanTicket;
import take_away_assistant.others.BaseException;

public interface IFullManager {

	public List<BeanFull> loadFull()throws BaseException;
}
