package take_away_assistant.example;

import java.awt.Frame;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import take_away_assistant.Itf.IUserManager;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;
import take_away_assistant.ui.FrmComMsg;
import take_away_assistant.ui.FrmSMsg;


public class ExampleUserManager implements IUserManager {

	
	
	public BeanUser reg(String name,String tel,String pwd,String pwd2) throws BaseException {
		if(name==null || "".equals(name))throw new BusinessException("��������Ϊ��!");
		if(tel==null || "".equals(tel))throw new BusinessException("�ֻ����벻��Ϊ��!");
		if(pwd==null || "".equals(pwd))throw new BusinessException("���벻��Ϊ��!");
		if(!pwd.equals(pwd2)) throw new BusinessException("��������������벻һ�£�");

		Connection conn=null;
		try {
			String sql="select customer_tel from customer_msg where customer_tel=?";//?ռλ��
			conn=DBUtil.getConnection();
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,tel);
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){
				
				rs.close();
				pst.close();
				throw new BusinessException("�û��Ѵ���");
			}
			pst.close();
			
			sql="select max(customer_id) from customer_msg";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			int cid = 0;
			if(rs.next()){
				cid=rs.getInt(1);//��ȡcustomer_id
			}
			rs.close();
			st.close();
			
			sql="insert into customer_msg(customer_id,customer_pwd,customer_register_date,customer_tel,customer_name) values(?,?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1, cid+1);
			pst.setString(2, pwd);
			Timestamp t= new java.sql.Timestamp(System.currentTimeMillis());
			pst.setTimestamp(3,t);
			pst.setString(4, tel);
			pst.setString(5, name);
			pst.execute();
			BeanUser user=new BeanUser();
			user.setRegister_time(t);
			user.setUser_id(cid);
			user.setPwd(pwd);
			user.setcustomer_name(name);
			user.setcustomer_tel(tel);
			rs.close();
			pst.close();
			return user;
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public BeanUser login(String name, String pwd) throws BaseException {
		if(name==null || "".equals(name))throw new BusinessException("�û�������Ϊ��!");
		if(pwd==null || "".equals(pwd))throw new BusinessException("���벻��Ϊ��!");
		
		
		
		Connection conn=null;
		try {
			BeanUser user=null;
			conn=DBUtil.getConnection();
			String sql="select customer_id,customer_name,customer_sex,"
					+ "customer_pwd,customer_tel,customer_mail,"
					+ "customer_city,customer_register_date,vip,"
					+ "vip_deadline from customer_msg where customer_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,name);
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){//�û�����
				if(rs.getString("customer_pwd").equals(pwd)) {//success	
					
					user=new BeanUser();
					user.setUser_id(rs.getInt(1));
					user.setcustomer_name(name);
					user.setcustomer_sex(rs.getString(3));
					user.setPwd(pwd);
					user.setcustomer_tel(rs.getString(5));
					user.setcustomer_mail(rs.getString(6));
					user.setcustomer_city(rs.getString(7));
					user.setRegister_time(rs.getTimestamp(8));
					user.setVip(rs.getString(9));
					user.setvip_deadline(rs.getTimestamp(10));
					rs.close();
					pst.close();
					return user;
				}
				else{
					throw new BusinessException("�û��������벻��ȷ��");
				}
				
			}
			else throw new BusinessException("�û��������ڣ�");
			
			
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void changePwd(BeanUser user, String oldPwd, String newPwd,
			String newPwd2) throws BaseException {

		if(oldPwd==null || "".equals(oldPwd))throw new BusinessException("ԭ���벻��Ϊ��!");
		if(newPwd==null || "".equals(newPwd))throw new BusinessException("�����벻��Ϊ��!");
		if(newPwd2==null || "".equals(newPwd2))throw new BusinessException("�����벻��Ϊ��!");
		if(!newPwd.equals(newPwd2)) throw new BusinessException("�������벻һ�£�");
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select customer_pwd from customer_msg where customer_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,user.getcustomer_name());
			java.sql.ResultSet rs=pst.executeQuery();//��ѯ
			if(rs.next()){
				if(!rs.getString("customer_pwd").equals(oldPwd)){
					throw new BusinessException("ԭ���벻��ȷ��");
				}
			
			
			else{
				
				//String sql1="update tbl_user set user_Pwd=?,register_time=? where user_id=?;";
				sql="update customer_msg set customer_Pwd=? where customer_name=?";
				pst=conn.prepareStatement(sql);
				pst.setString(1,newPwd);
				//pst.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
				pst.setString(2, user.getcustomer_name());
				pst.execute();//�޸�
				//user.setRegister_time(new Date());
				user.setPwd(newPwd2);
				user.setUser_id(user.getUser_id());
				rs.close();
				pst.close();
				
			}
			}
			
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	
		
	}

	@Override
	public void comMsg(BeanUser user, String edtName, String edtSex,
			String edtMail, String edtCity) throws BaseException {
		System.out.println(edtName+"!"+edtSex+"!"+edtMail+"!"+edtCity);
		System.out.print(FrmComMsg.l[0]);System.out.print(FrmComMsg.l[1]);
		System.out.print(FrmComMsg.l[2]);System.out.println(FrmComMsg.l[3]);
		if((edtName==null || "".equals(edtName))&&Array.getInt(FrmComMsg.l, 0)==1)throw new BusinessException("��������Ϊ��!");
		if((edtSex==null || "".equals(edtSex))&&Array.getInt(FrmComMsg.l, 1)==1)throw new BusinessException("�Ա���Ϊ��!");
		if((edtMail==null || "".equals(edtMail))&&Array.getInt(FrmComMsg.l, 2)==1)throw new BusinessException("���䲻��Ϊ��!");
		if((edtCity==null || "".equals(edtCity))&&Array.getInt(FrmComMsg.l, 3)==1)throw new BusinessException("���в���Ϊ��!");
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="update customer_msg"
					+ " set customer_name=?,customer_sex=?,customer_mail=?,"
					+ "customer_city=? "
					+ "where customer_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,edtName);
			pst.setString(2,edtSex);
			pst.setString(3,edtMail);
			pst.setString(4,edtCity);
			pst.setString(5,user.getcustomer_name());
			pst.execute();
			BeanUser.currentLoginUser.setcustomer_name(edtName);
			BeanUser.currentLoginUser.setcustomer_sex(edtSex);
			BeanUser.currentLoginUser.setcustomer_mail(edtMail);
			BeanUser.currentLoginUser.setcustomer_city(edtCity);
			
		} catch (SQLException e) {
			
			throw new DbException(e);
			
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}
				catch(SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void sMsg(BeanUser user) {
		Frame FrmSMsg = null;
		// TODO Auto-generated method stub
		FrmSMsg dlg=new FrmSMsg(FrmSMsg,"�鿴��Ϣ",true);
		dlg.setVisible(true);
	}

	
	

}
