package take_away_assistant.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;





import javax.swing.JOptionPane;

import take_away_assistant.Itf.IAddrManager;
import take_away_assistant.bean.BeanAddr;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;
import take_away_assistant.others.BusinessException;
import take_away_assistant.others.DBUtil;
import take_away_assistant.others.DbException;

public class ExampleAddrManager implements IAddrManager {

	
	@Override
	public List<BeanAddr> loadAddress() throws BaseException {
		List<BeanAddr> result=new ArrayList<BeanAddr>();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			String sql="SELECT address_id,customer_id,province,"
					+ "town,block,specific_address,contact_name,contact_tel"
					+ " from address "
					+ "where customer_id=? order by address_id";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, BeanUser.currentLoginUser.getUser_id());//�û�������ڲ�ѯ
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanAddr p=new BeanAddr();
				p.setAddress_id(rs.getInt(1));
				p.setCustomer_id(rs.getInt(2));
				p.setProvience(rs.getString(3));
				p.setTown(rs.getString(4));
				p.setBlock(rs.getString(5));
				p.setSpecific_address(rs.getString(6));
				p.setContact_name(rs.getString(7));
				p.setContact_tel(rs.getString(8));
				
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
		
		}
		catch(SQLException ex){
			throw new DbException(ex);
		}
		finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	@Override
	public void delete(BeanAddr addr) throws BaseException {//ɾ����ַ
		int address_id=addr.getAddress_id();
		int customer_id=addr.getCustomer_id();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="select customer_id from address where address_id="+address_id+" and customer_id="+customer_id;
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				customer_id=rs.getInt(1);
			}
			else {
				rs.close();
				st.close();
				throw new BusinessException("�õ�ַ������");
			}
			
			rs.close();
			if(BeanUser.currentLoginUser.getUser_id()!=customer_id){
				st.close();
				throw new BusinessException("����ɾ�����˵ĵ�ַ");
			}
			
			sql="delete from address where address_id="+address_id+" and customer_id="+customer_id;
			st.execute(sql);
			st.close();
			
			//����address_id
			sql="update address set address_id=0-address_id where customer_id="+customer_id+" and address_id>"+address_id;
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			//pst.setInt(1,plan_id);
			pst.execute();
			sql="update address set address_id=-1-address_id where customer_id="+customer_id+" and address_id<"+0;
			pst=conn.prepareStatement(sql);
			//pst.setInt(1, plan_id);
			pst.execute();
			conn.commit();
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw new DbException(ex);
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public BeanAddr add(String province,String town,String block,String speci,String name,String tel) throws BaseException {//������ַ
		if(province==null||"".equals(province)) throw new BusinessException("ʡ����Ϊ��");
		if(town==null||"".equals(town)) throw new BusinessException("�в���Ϊ��");
		if(block==null||"".equals(block)) throw new BusinessException("�����أ�����Ϊ��");
		if(speci==null||"".equals(speci)) throw new BusinessException("��ϸ��ַ����Ϊ��");
		if(name==null||"".equals(name)) throw new BusinessException("��ϵ�˲���Ϊ��");
		if(tel==null||"".equals(tel)) throw new BusinessException("��ϵ�绰����Ϊ��");
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			int customer_id=BeanUser.currentLoginUser.getUser_id(); 
			int address_id=0;
			
			String sql="select max(address_id) from address where customer_id="+customer_id;
			java.sql.Statement st=conn.prepareStatement(sql);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) address_id=rs.getInt(1)+1;
			rs.close();
			st.close();
	
			sql="INSERT INTO `take1`.`address` (`address_id`, `customer_id`, `province`, `town`, `block`, `specific_address`, `contact_name`, `contact_tel`) "
					+ "VALUES ("+address_id+","+customer_id+","
					+ "?,?,?,?,?,?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst=conn.prepareStatement(sql);
			pst.setString(1, province);
			pst.setString(2, town);
			pst.setString(3, block);
			pst.setString(4, speci);
			pst.setString(5, name);
			pst.setString(6, tel);
			
			pst.execute();
			pst.close();
			
			BeanAddr p =new BeanAddr();//���÷���ֵ
			sql="select max(address_id) from address where address_id="+address_id+" and customer_id="+customer_id;//max��ȡ���������� ����ǰ��address
			pst=conn.prepareStatement(sql);
			rs=pst.executeQuery();
			if(rs.next()){
				p.setAddress_id(address_id);
				p.setCustomer_id(customer_id);
				p.setProvience(province);
				p.setTown(town);
				p.setBlock(block);
				p.setSpecific_address(speci);
				p.setContact_name(name);
				p.setContact_tel(tel);
			}
			pst.close();
			
			return p;
		}catch(SQLException ex){
			ex.printStackTrace();
			throw new DbException(ex);
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}


	@Override
	public void update(BeanAddr addr, String province, String town,
			String block, String speci, String name, String tel)
			throws BaseException {
		if(province==null||"".equals(province)) throw new BusinessException("ʡ����Ϊ��");
		if(town==null||"".equals(town)) throw new BusinessException("�в���Ϊ��");
		if(block==null||"".equals(block)) throw new BusinessException("�����أ�����Ϊ��");
		if(speci==null||"".equals(speci)) throw new BusinessException("��ϸ��ַ����Ϊ��");
		if(name==null||"".equals(name)) throw new BusinessException("��ϵ�˲���Ϊ��");
		if(tel==null||"".equals(tel)) throw new BusinessException("��ϵ�绰����Ϊ��");
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
			int customer_id=BeanUser.currentLoginUser.getUser_id(); 
			int address_id=0;
			
			String sql="select max(address_id) from address where customer_id="+customer_id;
			java.sql.Statement st=conn.prepareStatement(sql);
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) address_id=rs.getInt(1)+1;
			rs.close();
			st.close();
	
			sql="update address set province=?,town=?,block=?,specific_address=?,"
					+ "contact_name=?,contact_tel=? "
					+ "WHERE address_id=? and customer_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst=conn.prepareStatement(sql);
			pst.setString(1, province);
			pst.setString(2, town);
			pst.setString(3, block);
			pst.setString(4, speci);
			pst.setString(5, name);
			pst.setString(6, tel);
			pst.setInt(7, addr.getAddress_id());
			pst.setInt(8, addr.getCustomer_id());
			pst.execute();
			pst.close();
			
			BeanAddr p =new BeanAddr();//���÷���ֵ
			sql="select max(address_id) from address where address_id="+address_id+" and customer_id="+customer_id;//max��ȡ���������� ����ǰ��address
			pst=conn.prepareStatement(sql);
			rs=pst.executeQuery();
			if(rs.next()){
				p.setAddress_id(address_id);
				p.setCustomer_id(customer_id);
				p.setProvience(province);
				p.setTown(town);
				p.setBlock(block);
				p.setSpecific_address(speci);
				p.setContact_name(name);
				p.setContact_tel(tel);
			}
			pst.close();
			JOptionPane.showMessageDialog(null, "�޸ĳɹ�"); 
			return;
		}catch(SQLException ex){
			ex.printStackTrace();
			throw new DbException(ex);
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}

}
