package take_away_assistant.others;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
