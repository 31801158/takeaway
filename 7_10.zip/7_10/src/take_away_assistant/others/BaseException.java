package take_away_assistant.others;

public class BaseException  extends Exception {
	public BaseException(String msg){
		super(msg);
	}
}
