package take_away_assistant.ui;

public class FrmSTicket {

}
