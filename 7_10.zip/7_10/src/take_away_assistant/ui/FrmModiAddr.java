package take_away_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import take_away_assistant.util;
import take_away_assistant.others.BaseException;

public class FrmModiAddr  extends JDialog implements ActionListener {

	private static final String FrmSMsg = null;
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	private JLabel labelProvince = new JLabel("ʡ��            ");
	private JTextField edtProvince = new JTextField(20);
	private JLabel labelTown = new JLabel    ("�У�           ");
	private JTextField edtTown = new JTextField(20);
	private JLabel labelBlock = new JLabel   ("�����أ���");
	private JTextField edtBlock = new JTextField(20);
	private JLabel labelSpeci = new JLabel   ("��ϸ��ַ��");
	private JTextField edtSpeci = new JTextField(20);
	private JLabel labelConName = new JLabel ("��ϵ�ˣ�    ");
	private JTextField edtConName = new JTextField(20);
	private JLabel labelConTel = new JLabel  ("��ϵ�绰��");
	private JTextField edtConTel = new JTextField(20);
	
	public FrmModiAddr(FrmSAddr frmSAddr, String s, boolean b) {
		super(frmSAddr, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		edtProvince.setText(FrmSAddr.a.getProvience());
		edtTown.setText(FrmSAddr.a.getTown());
		edtBlock.setText(FrmSAddr.a.getBlock());
		edtSpeci.setText(FrmSAddr.a.getSpecific_address());
		edtConName.setText(FrmSAddr.a.getContact_name());
		edtConTel.setText(FrmSAddr.a.getContact_tel());
		workPane.add(labelProvince);
		workPane.add(edtProvince);
		workPane.add(labelTown);
		workPane.add(edtTown);
		workPane.add(labelBlock);
		workPane.add(edtBlock);
		workPane.add(labelSpeci);
		workPane.add(edtSpeci);
		workPane.add(labelConName);
		workPane.add(edtConName);
		workPane.add(labelConTel);
		workPane.add(edtConTel);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(330, 280);
		
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);
		
		//��ʾ����Ļ�м�
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		this.validate();
}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){
			String province=edtProvince.getText();
			String town=edtTown.getText();
			String block=edtBlock.getText();
			String speci=edtSpeci.getText();
			String name=edtConName.getText();
			String tel=edtConTel.getText();
			try {
				util.addressManager.update(FrmSAddr.a,province,town,block,speci,name,tel);
				this.setVisible(false);
				return;
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			
		}
		
	}

}
