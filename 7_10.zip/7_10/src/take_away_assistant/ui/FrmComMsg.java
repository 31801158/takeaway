package take_away_assistant.ui;


import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import take_away_assistant.util;
import take_away_assistant.bean.BeanUser;
import take_away_assistant.others.BaseException;




public class FrmComMsg extends JDialog implements ActionListener{
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ���޸�");
	private Button btnCancel = new Button("ȡ��");
	
	
	private JLabel labelID = new JLabel          ("ID��                  ");
	private JLabel labelName = new JLabel        ("������               ");
	private JLabel labelSex = new JLabel         ("�Ա�                ");
	private JLabel labelTel = new JLabel         ("�ֻ����룺        ");
	private JLabel labelMail = new JLabel        ("���䣺                ");
	private JLabel labelCity = new JLabel        ("���ڳ��У�        ");
	private JLabel labelRegisterTime = new JLabel("ע��ʱ�䣺        ");
	private JLabel labelVip = new JLabel         ("�Ƿ�Ϊ��Ա��    ");
	private JLabel labelVipdeadline = new JLabel ("��Ա��ֹ���ڣ�");
	private JLabel labelBlank1 = new JLabel ("");
	private JLabel labelBlank2 = new JLabel ("");
	private JLabel labelBlank3 = new JLabel ("");
	private JLabel labelBlank4 = new JLabel ("");
	private JLabel labelBlank5 = new JLabel ("");
	private JLabel labelBlank12 = new JLabel ("");
	private JLabel labelBlank22 = new JLabel ("");
	private JLabel labelBlank32 = new JLabel ("");
	private JLabel labelBlank42 = new JLabel ("");
	private JLabel labelBlank52 = new JLabel ("");
	private Button btnmodiName = new Button("ȥ�޸�");
	private Button btnmodiSex = new Button("ȥ�޸�");
	private Button btnmodiMail = new Button("ȥ�޸�");
	private Button btnmodiCity = new Button("ȥ�޸�");
	private JTextField edtName=new JTextField(30);
	private JTextField edtSex=new JTextField(30);
	private JTextField edtMail=new JTextField(30);
	private JTextField edtCity=new JTextField(30);
	
	private JLabel labelID1 = new JLabel(Integer.toString(BeanUser.currentLoginUser.getUser_id()));
	private JLabel labelName1 = new JLabel        ("");
	private JLabel labelSex1 = new JLabel         ("");
	
	private JLabel labelTel1 = new JLabel         (BeanUser.currentLoginUser.getcustomer_tel()); //(BeanUser.currentLoginUser.getcustomer_tel());
	private JLabel labelMail1 = new JLabel        ("");
	private JLabel labelCity1 = new JLabel        ("");
	String redatetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(BeanUser.currentLoginUser.getRegister_time());  // ��ȡ������ʱ����
	private JLabel labelRegisterTime1 = new JLabel(redatetime+"          ");
	private JLabel labelVip1 = new JLabel("�ǻ�Ա");
	private JLabel labelVipdeadline1 = new JLabel("");
	
	public FrmComMsg(Frame f, String s, boolean b) {
		super(f, s, b);
		Array.setInt(l, 0, 0);
		Array.setInt(l, 1, 0);
		Array.setInt(l, 2, 0);
		Array.setInt(l, 3, 0);
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.setLayout(new GridLayout(9,4));
		
		if(BeanUser.currentLoginUser.getcustomer_name()==null||"".equals(BeanUser.currentLoginUser.getUser_id()))
			labelName1.setText("δ����");
		else
			labelName1.setText(BeanUser.currentLoginUser.getcustomer_name());
		
		if(BeanUser.currentLoginUser.getcustomer_sex()==null||"".equals(BeanUser.currentLoginUser.getUser_id()))
			labelSex1.setText("δ����");
		else
			labelSex1.setText(BeanUser.currentLoginUser.getcustomer_sex());
		
		if(BeanUser.currentLoginUser.getcustomer_mail()==null||"".equals(BeanUser.currentLoginUser.getcustomer_mail()))
			labelMail1.setText("δ����");
		else
			labelMail1.setText(BeanUser.currentLoginUser.getcustomer_mail());
		if(BeanUser.currentLoginUser.getcustomer_city()==null||"".equals(BeanUser.currentLoginUser.getcustomer_city()))
			labelCity1.setText("δ����");
		else 
			labelCity1.setText(BeanUser.currentLoginUser.getcustomer_city());
		

		String ifvip = new String();
		if(BeanUser.currentLoginUser.getVip().equals("��")){
			String deadlinedatetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(BeanUser.currentLoginUser.getvip_deadline());
			ifvip="��vip";
			labelVipdeadline1.setText(deadlinedatetime.substring(0,10));//������10
		} 
		else ifvip="����";
		labelVip1.setText(ifvip);
		
		workPane.add(labelID);
		workPane.add(labelID1);
		workPane.add(labelBlank1);
		workPane.add(labelBlank12);
		workPane.add(labelName);
		workPane.add(labelName1);
		workPane.add(btnmodiName);
		workPane.add(edtName);
		this.edtName.setVisible(false);
		workPane.add(labelSex);
		workPane.add(labelSex1);
		workPane.add(btnmodiSex);
		workPane.add(edtSex);
		this.edtSex.setVisible(false);
		workPane.add(labelTel);
		workPane.add(labelTel1);
		workPane.add(labelBlank2);
		workPane.add(labelBlank22);
		workPane.add(labelMail);
		workPane.add(labelMail1);
		workPane.add(btnmodiMail);
		workPane.add(edtMail);
		this.edtMail.setVisible(false);
		workPane.add(labelCity);
		workPane.add(labelCity1);
		workPane.add(btnmodiCity);
		workPane.add(edtCity);
		this.edtCity.setVisible(false);
		workPane.add(labelRegisterTime);
		workPane.add(labelRegisterTime1);
		workPane.add(labelBlank3);
		workPane.add(labelBlank32);
		workPane.add(labelVip);
		workPane.add(labelVip1);
		workPane.add(labelBlank4);
		workPane.add(labelBlank42);
		workPane.add(labelVipdeadline);
		workPane.add(labelVipdeadline1);
		workPane.add(labelBlank5);
		workPane.add(labelBlank52);

		
				
		this.btnmodiName.addActionListener(this);
		this.btnmodiSex.addActionListener(this);
		this.btnmodiMail.addActionListener(this);
		this.btnmodiCity.addActionListener(this);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(500, 340);
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		
		//��ʾ����Ļ�м�
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		this.validate();
	}
	public static  int l[] ={0,0,0,0};
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==this.btnmodiName){
			this.edtName.setVisible(true);
			workPane.add(this.edtName);
			Array.setInt(l, 0, 1);
			}
		else if(e.getSource()==this.btnmodiSex){
			this.edtSex.setVisible(true);
			workPane.add(this.edtName);
			Array.setInt(l, 1, 1);
			}
		else if(e.getSource()==this.btnmodiMail){
			this.edtMail.setVisible(true);
			workPane.add(this.edtName);
			Array.setInt(l, 2, 1);
			}
		else if(e.getSource()==this.btnmodiCity){
			this.edtCity.setVisible(true);
			workPane.add(this.edtName);
			Array.setInt(l, 3, 1);
			}
		if(e.getSource()==this.btnCancel){//ȡ�������
			this.setVisible(false);
			Array.setInt(l, 0, 0);
			Array.setInt(l, 1, 0);
			Array.setInt(l, 2, 0);
			Array.setInt(l, 3, 0);	
		}
		else if(e.getSource()==this.btnOk){
			try {
				int i;
				String s1=new String();
				String s2=new String();
				String s3=new String();
				String s4=new String();
				if(Array.getInt(l, 0)==1){
					s1=edtName.getText();
				}
				else s1=BeanUser.currentLoginUser.getcustomer_name();
				if(Array.getInt(l, 1)==1){
					s2=edtSex.getText();
				}else s2=BeanUser.currentLoginUser.getcustomer_sex();
				
				if(Array.getInt(l, 2)==1){
					s3=edtMail.getText();
				}else s3=BeanUser.currentLoginUser.getcustomer_mail();
				if(Array.getInt(l, 3)==1){
					s4=edtCity.getText();
				}else s4=BeanUser.currentLoginUser.getcustomer_city();
				
				util.userManager.comMsg(BeanUser.currentLoginUser,s1,s2,s3,s4);
				Array.setInt(l, 0, 0);//ȷ���޸ĺ����
				Array.setInt(l, 1, 0);
				Array.setInt(l, 2, 0);
				Array.setInt(l, 3, 0);
				this.setVisible(false);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
	}

}
