package take_away_assistant.bean;

public class BeanRider {
	
}
