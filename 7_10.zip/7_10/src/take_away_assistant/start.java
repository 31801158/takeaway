package take_away_assistant;

import take_away_assistant.ui.FrmMain;

public class start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
